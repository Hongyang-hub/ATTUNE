"""Index the DICOM SEG series of NLST501 on TCIA (one per read) and download one per participant; scripts/solid_component.py
fetches the remaining series of each participant on the fly.
Output: data/raw/nlst501/seg/<pid>/<seg_uid>.dcm and data/raw/nlst501/seg/seg_index.csv
"""
import csv, io, os, subprocess, zipfile, json
from concurrent.futures import ThreadPoolExecutor

B = "https://services.cancerimagingarchive.net/nbia-api/services/v1"
OUT = "data/raw/nlst501/seg"


def curl(url, binary=False):
    r = subprocess.run(["curl", "-s", "--ciphers", "DEFAULT@SECLEVEL=1", "--max-time", "300", url], capture_output=True)
    return r.stdout if binary else r.stdout.decode("utf8", "replace")


def meta(uid):
    for _ in range(3):
        try:
            m = json.loads(curl(f"{B}/getSeriesMetaData?SeriesInstanceUID={uid}"))[0]
            return uid, m["Subject ID"], m["Series Description"]
        except Exception:  # noqa: BLE001
            pass
    return uid, None, None


def fetch(args):
    uid, pid = args
    d = os.path.join(OUT, pid); os.makedirs(d, exist_ok=True)
    if any(f.endswith(".dcm") for f in os.listdir(d)):
        return pid, "exists"
    data = curl(f"{B}/getImage?SeriesInstanceUID={uid}", binary=True)
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for n in z.namelist():
                if n.endswith(".dcm"):
                    open(os.path.join(d, uid + ".dcm"), "wb").write(z.read(n))
        return pid, "ok"
    except Exception as e:  # noqa: BLE001
        return pid, f"fail {e}"


def main():
    uids = [l.strip() for l in open("data/raw/nlst501/LIDC-annot-NLST501_Seg.tcia") if l.strip().startswith("1.")]
    idx_path = os.path.join(OUT, "seg_index.csv"); os.makedirs(OUT, exist_ok=True)
    if os.path.exists(idx_path):
        rows = list(csv.reader(open(idx_path)))[1:]
    else:
        with ThreadPoolExecutor(8) as ex:
            rows = list(ex.map(meta, uids))
        with open(idx_path, "w", newline="") as fh:
            w = csv.writer(fh); w.writerow(["seg_uid", "pid", "description"]); w.writerows(rows)
    first = {}
    for uid, pid, desc in rows:
        if pid and pid not in first:
            first[pid] = uid
    print("SEG series:", len(rows), "patients:", len(first), flush=True)
    with ThreadPoolExecutor(6) as ex:
        res = list(ex.map(fetch, [(u, p) for p, u in first.items()]))
    print({s.split()[0]: sum(1 for _, x in res if x.split()[0] == s.split()[0]) for _, s in res})


if __name__ == "__main__":
    main()
