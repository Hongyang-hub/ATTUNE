"""One ATTUNE run: an embedded multi-objective algorithm searches rule tables on the search folds.

    python scripts/run_search.py --design main --seed 0                       # SPEA2, main design
    python scripts/run_search.py --design nested --outer 2 --seed 0 --algo nsga3

Population 100 (LR-full + 99 random repaired tables, identical across algorithms for a given seed), 10,000 evaluations,
SBX (0.9, eta 15) and polynomial mutation (eta 20) with rounding where an algorithm uses them, repair, four objectives on
the search folds. Saves the archive of all evaluated tables and its non-dominated set (runs/search/<tag>.npz).
"""
import argparse, os, sys, time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from data import load, pids_in, design_folds                                   # noqa: E402
from search import Evaluator, N_GENES, XL, XU, repair, lrfull_genome          # noqa: E402

from pymoo.algorithms.moo.spea2 import SPEA2                                   # noqa: E402
from pymoo.core.mating import Mating                                           # noqa: E402
from pymoo.core.duplicate import NoDuplicateElimination                        # noqa: E402
from pymoo.core.problem import Problem                                         # noqa: E402
from pymoo.core.sampling import Sampling                                       # noqa: E402
from pymoo.core.repair import Repair                                           # noqa: E402
from pymoo.operators.crossover.sbx import SBX                                  # noqa: E402
from pymoo.operators.mutation.pm import PM                                     # noqa: E402
from pymoo.operators.repair.rounding import RoundingRepair                     # noqa: E402
from pymoo.operators.selection.tournament import TournamentSelection          # noqa: E402
from pymoo.algorithms.moo.spea2 import spea_binary_tournament                  # noqa: E402
from pymoo.algorithms.moo.nsga2 import NSGA2, binary_tournament                 # noqa: E402
from pymoo.algorithms.moo.nsga3 import NSGA3, comp_by_cv_then_random            # noqa: E402
from pymoo.algorithms.moo.sms import SMSEMOA, cv_and_dom_tournament             # noqa: E402
from pymoo.algorithms.moo.moead import MOEAD                                    # noqa: E402
from pymoo.algorithms.moo.rvea import RVEA                                      # noqa: E402
from pymoo.algorithms.moo.age2 import AGEMOEA2                                  # noqa: E402
from pymoo.algorithms.moo.gde3 import GDE3                                      # noqa: E402
from pymoo.algorithms.moo.mopso_cd import MOPSO_CD                              # noqa: E402
from pymoo.algorithms.moo.cmopso import CMOPSO                                  # noqa: E402
from pymoo.util.ref_dirs import get_reference_directions                        # noqa: E402
from pymoo.optimize import minimize                                            # noqa: E402
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting          # noqa: E402

POP, BUDGET = 100, 10_000
GA = ("spea2", "nsga2", "nsga3", "smsemoa")                 # mating with SBX/PM and the algorithm's tournament
PYMOO = ("moead", "rvea", "agemoea2", "gde3", "mopsocd", "cmopso")
# own implementations in src/moeas/<name>.py, each exposing make(sampling, repair, crossover, mutation, pop_size, ref_dirs)
EXTRA = ("nrvmoea", "pdmaoea", "tnsga2", "prvnsga2", "maoeahap", "twoarch2", "ibea", "moeadde", "smpso", "admopso")
ALGOS = GA + PYMOO + tuple(m for m in EXTRA if os.path.exists(os.path.join(os.path.dirname(__file__), "..", "src", "moeas",
                                                                           m + ".py")))


class RuleRepair(Repair):
    def _do(self, problem, X, **kw):
        return repair(np.round(X).astype(int)).astype(float)


class FixedSampling(Sampling):
    """The run's initial population (LR-full + 99 repaired random tables) for algorithms that call sampling.do."""
    def __init__(self, X):
        super().__init__(); self.X = X

    def _do(self, problem, n_samples, **kw):
        return self.X[:n_samples].copy()


class SeededSurvival:
    """pymoo's CMOPSO calls its survival without the algorithm's random state, which makes runs irreproducible."""
    def __init__(self, inner, alg):
        self.inner, self.alg = inner, alg

    def do(self, *a, **k):
        k.setdefault("random_state", self.alg.random_state)
        return self.inner.do(*a, **k)


class RuleProblem(Problem):
    def __init__(self, ev):
        super().__init__(n_var=N_GENES, n_obj=4, xl=XL, xu=XU, vtype=int)
        self.ev, self.archive_X, self.archive_F = ev, [], []

    def _evaluate(self, X, out, *a, **k):
        Xi = repair(np.round(X).astype(int))       # idempotent for the GA operators, which repair before evaluation
        F = self.ev.F(Xi)
        self.archive_X.append(Xi); self.archive_F.append(F)
        out["F"] = F


def seed_unseeded_generators(seed):
    """pymoo's external archive (used by MOPSO-CD and CMOPSO) truncates with np.random.default_rng() without a seed;
    give such calls generators derived from the run seed so that runs are reproducible. Seeded calls are unchanged."""
    orig, ss = np.random.default_rng, np.random.SeedSequence([seed, 20261007])
    np.random.default_rng = lambda s=None: orig(ss.spawn(1)[0] if s is None else s)


def nondominated(X, F):
    X, idx = np.unique(X, axis=0, return_index=True)
    F = F[idx]
    front = NonDominatedSorting().do(F, only_non_dominated_front=True)
    return X[front], F[front]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--design", choices=["main", "nested"], default="main")
    ap.add_argument("--outer", type=int, default=-1)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--algo", choices=list(ALGOS), default="spea2")
    ap.add_argument("--budget", type=int, default=BUDGET)
    ap.add_argument("--out", default="runs/search")
    a = ap.parse_args()
    nod, reads, cancer, fold = load()
    s_f, _, _ = design_folds(a.design, a.outer)
    ev = Evaluator(nod, reads, cancer, pids_in(fold, s_f))
    seed_unseeded_generators(a.seed)
    rng = np.random.default_rng(a.seed)
    init = repair(np.vstack([lrfull_genome(), rng.integers(XL, XU + 1, size=(POP - 1, N_GENES))])).astype(float)
    comp = {"spea2": spea_binary_tournament, "nsga2": binary_tournament, "nsga3": comp_by_cv_then_random,
            "smsemoa": cv_and_dom_tournament}.get(a.algo, binary_tournament)
    mating = Mating(selection=TournamentSelection(func_comp=comp),
                    crossover=SBX(prob=0.9, eta=15, vtype=float, repair=RoundingRepair()),
                    mutation=PM(eta=20, vtype=float, repair=RoundingRepair()),
                    repair=RuleRepair(), eliminate_duplicates=NoDuplicateElimination())
    kw = dict(pop_size=POP, sampling=init, mating=mating, repair=RuleRepair(), eliminate_duplicates=False)
    rd = lambda: get_reference_directions("energy", 4, POP, seed=1)  # noqa: E731
    sbx, pm = SBX(prob=0.9, eta=15, vtype=float, repair=RoundingRepair()), PM(eta=20, vtype=float, repair=RoundingRepair())
    alg = {"spea2": lambda: SPEA2(**kw), "nsga2": lambda: NSGA2(**kw), "smsemoa": lambda: SMSEMOA(**kw),
           "nsga3": lambda: NSGA3(ref_dirs=rd(), **kw),
           # algorithms with their own reproduction; same initial population, SBX/PM where used
           "moead": lambda: MOEAD(ref_dirs=rd(), sampling=init, crossover=sbx, mutation=pm, repair=RuleRepair()),
           "rvea": lambda: RVEA(ref_dirs=rd(), pop_size=POP, sampling=init, crossover=sbx, mutation=pm, repair=RuleRepair(),
                                eliminate_duplicates=False),
           "agemoea2": lambda: AGEMOEA2(pop_size=POP, sampling=init, crossover=sbx, mutation=pm, repair=RuleRepair(),
                                        eliminate_duplicates=False),
           "gde3": lambda: GDE3(pop_size=POP, sampling=init, repair=RuleRepair()),
           "mopsocd": lambda: MOPSO_CD(pop_size=POP, sampling=FixedSampling(init)),
           "cmopso": lambda: CMOPSO(pop_size=POP, sampling=FixedSampling(init))}.get(a.algo)
    if alg is None:
        import importlib
        alg = lambda: importlib.import_module(f"moeas.{a.algo}").make(  # noqa: E731
            sampling=FixedSampling(init), repair=RuleRepair(), crossover=sbx, mutation=pm, pop_size=POP, ref_dirs=rd())
    alg = alg()
    if a.algo == "cmopso":
        alg.survival = SeededSurvival(alg.survival, alg)
    prob = RuleProblem(ev)
    t0 = time.time()
    # RVEA converts an evaluation budget to generations without counting the initial one; give it the same 10,000
    term = ("n_gen", a.budget // POP) if a.algo == "rvea" else ("n_evals", a.budget)
    minimize(prob, alg, term, seed=a.seed, verbose=False, copy_algorithm=False)
    AX, AF = np.vstack(prob.archive_X), np.vstack(prob.archive_F)
    NX, NF = nondominated(AX, AF)
    tag = f"{a.design}{'' if a.outer < 0 else a.outer}_{a.algo}_s{a.seed}"
    os.makedirs(a.out, exist_ok=True)
    np.savez(os.path.join(a.out, tag + ".npz"), X=NX, F=NF, archive_X=AX, archive_F=AF, seconds=time.time() - t0)
    print(tag, "evals", len(AX), "front", len(NX), f"{time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
