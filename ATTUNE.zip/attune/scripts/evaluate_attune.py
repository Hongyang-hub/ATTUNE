"""Evaluation of ATTUNE with twenty embedded algorithms (paper analyses). Writes tables for the figures to runs/attune/.

    REQUIRE_ALL=1 python scripts/evaluate_attune.py

Main-design comparison of the algorithms (hypervolume with global normalization, best qualifying selection-fold recall
discordance, Friedman tests, anytime hypervolume) defines the first tier: the algorithms whose hypervolume does not differ
from that of the best-ranked algorithm (Wilcoxon signed-rank over seeds, Holm-adjusted, 5%). Primary analysis: the runs
of the first-tier algorithms pooled per outer fold, nested cross-validation, the selection rule and success criteria.
Secondary: every embedded algorithm through the same nested procedure; out-of-sample trade-off between recall
discordance and the non-inferiority margin; test set, external safety and automated reading for the first-tier tables.
"""
import glob, json, os, sys, time
import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare, rankdata, spearmanr, wilcoxon

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from data import load, pids_in, design_folds, SOLID_COLS                                   # noqa: E402
from search import Evaluator, lrfull_genome, lra_genome, select, to_json                  # noqa: E402
from metrics import paired_ci                                                            # noqa: E402
from pymoo.indicators.hv import HV                                                       # noqa: E402
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting                    # noqa: E402

SR = "data/derived/sign_reader"                    # sign-reader predictions (derived data)
RUNS, OUT, SEEDS = os.environ.get("RUNS", "runs/search"), "runs/attune", range(10)
os.makedirs(OUT, exist_ok=True)
# name, label, family, year
ALGOS = [("spea2", "SPEA2", "Pareto dominance", 2001), ("nsga2", "NSGA-II", "Pareto dominance", 2002),
         ("agemoea2", "AGE-MOEA-II", "Pareto dominance", 2022),
         ("tnsga2", "Truthful NSGA-II", "Pareto dominance", 2026),
         ("prvnsga2", "PRV-NSGA-II", "Pareto dominance", 2024),
         ("pdmaoea", "PDMaOEA", "Pareto dominance", 2024),
         ("nsga3", "NSGA-III", "Reference vectors", 2014), ("rvea", "RVEA", "Reference vectors", 2016),
         ("nrvmoea", "NRV-MOEA", "Reference vectors", 2024),
         ("moead", "MOEA/D", "Decomposition", 2007), ("moeadde", "MOEA/D-DE", "Decomposition", 2009),
         ("ibea", "IBEA", "Indicators", 2004), ("smsemoa", "SMS-EMOA", "Indicators", 2007),
         ("twoarch2", "Two_Arch2", "Two archives", 2015),
         ("maoeahap", "MaOEA-HAP", "Two archives", 2026),
         ("mopsocd", "MOPSO-CD", "Particle swarm", 2005), ("cmopso", "CMOPSO", "Particle swarm", 2018),
         ("smpso", "SMPSO", "Particle swarm", 2009),
         ("admopso", "ADMOPSO", "Particle swarm", 2025),
         ("gde3", "GDE3", "Differential evolution", 2005)]
LAB = {a[0]: a[1] for a in ALGOS}
tag = lambda al, design, s: f"{design}_{al}_s{s}.npz"  # noqa: E731
files = lambda al: [f"{RUNS}/{tag(al, d, s)}" for d in ["main"] + [f"nested{k}" for k in range(5)] for s in SEEDS]  # noqa: E731
avail = [a for a in ALGOS if all(os.path.exists(f) for f in files(a[0]))]
if os.environ.get("REQUIRE_ALL"):
    assert len(avail) == 20, [a[0] for a in ALGOS if a not in avail]
NAMES = [a[0] for a in avail]
pd.DataFrame(avail, columns=["algo", "label", "family", "year"]).to_csv(f"{OUT}/algorithms.csv", index=False)

LRF, LRA = lrfull_genome(), lra_genome()
NODS = {m: load(m) for m in SOLID_COLS}
nod, reads, cancer, fold = NODS["-300 HU"]
lines = []


def say(s=""):
    print(s, flush=True); lines.append(s)


def ev_on(folds, measure="-300 HU"):
    n, r, c, f = NODS[measure]
    return Evaluator(n, r, c, pids_in(f, folds))


EV = {}


def ev_c(folds, measure="-300 HU"):
    k = (tuple(folds), measure)
    if k not in EV:
        EV[k] = ev_on(folds, measure)
    return EV[k]


def rates(ev, g):
    return pd.DataFrame({"cancer": ev.cancer, **ev.patient_rates(g)}, index=ev.pids).sort_index()


def strat_ci(d, strata, n_boot=10000, seed=0):
    d, strata = np.asarray(d, float), np.asarray(strata)
    rng = np.random.default_rng(seed); bs = np.zeros(n_boot)
    for s in np.unique(strata):
        x = d[strata == s]; bs += x[rng.integers(0, len(x), size=(n_boot, len(x)))].mean(1) * len(x) / len(d)
    return 100 * d.mean(), 100 * np.percentile(bs, 2.5), 100 * np.percentile(bs, 97.5)


EP = (("recall_disc", None, "recall_disc"), ("level_disc", None, "level_disc"), ("miss", True, "miss"),
      ("under", True, "under"), ("fp_recall", False, "fp_recall"), ("ge3m", False, "nc_ge3m"), ("over", False, "over"),
      ("ge3m", True, "c_ge3m"))


def compare(E, C, **tags):
    E, C = E.sort_index(), C.sort_index(); assert (E.index == C.index).all()
    out = []
    for col, grp, nm in EP:
        if grp is None:
            sel = np.ones(len(E), bool); d, lo, hi = strat_ci((E[col] - C[col]).to_numpy(), E.cancer.to_numpy())
        else:
            sel = E.cancer.to_numpy() == grp; d, lo, hi = paired_ci((E[col] - C[col]).to_numpy()[sel])
        out.append(dict(**tags, metric=nm, n=int(sel.sum()), rule=100 * E[col][sel].mean(), comp=100 * C[col][sel].mean(),
                        diff=d, lo=lo, hi=hi))
    return pd.DataFrame(out)


def pooled(al, design):
    """Union of the non-dominated sets of all runs of one algorithm or of a list of algorithms."""
    algos = [al] if isinstance(al, str) else al
    return np.unique(np.vstack([np.load(f"{RUNS}/{tag(a, design, s)}")["X"] for a in algos for s in SEEDS]), axis=0)


def nested_tables(al, margin=0.0):
    """Selected table per outer fold (LR-full when none qualifies) and per-fold details."""
    T, info = [], []
    for k in range(5):
        _, sel_f, _ = design_folds("nested", k)
        X = pooled(al, f"nested{k}")
        es = ev_c(sel_f)
        M = np.array([es.constraint_metrics(g) for g in X]) if margin else None
        if margin:
            ref = es.constraint_metrics(LRF)
            ok = np.all(M[:, :4] <= ref[:4] + margin + 1e-12, axis=1)
            g = X[np.flatnonzero(ok)[np.argmin(M[ok, 4])]] if ok.any() else None
        else:
            g, M = select(X, es, LRF)
            ref = es.constraint_metrics(LRF)
            ok = np.all(M[:, :4] <= ref[:4] + 1e-12, axis=1)
        T.append(LRF if g is None else g)
        info.append(dict(algo=al if isinstance(al, str) else "+".join(al), outer=k, pooled=len(X), qualifying=int(ok.sum()), lrfull_kept=g is None,
                         sel_disc=100 * es.constraint_metrics(T[-1])[4], sel_disc_lrfull=100 * ref[4]))
    return T, info


def oof(T, measure="-300 HU"):
    E = pd.concat([rates(ev_c([k], measure), T[k]) for k in range(5)])
    C = pd.concat([rates(ev_c([k], measure), LRF) for k in range(5)])
    return E, C


# =============================== equal evaluations ===============================
used = [f for a in NAMES for f in files(a)]
bad = {f: n for f in used if (n := len(np.load(f)["archive_X"])) != 10_000}
assert not bad, bad
say(f"== {len(NAMES)} algorithms, {len(used)} runs, every run evaluated exactly 10,000 tables")

# =============================== main design comparison ===============================
say("\n== main design: ten runs per algorithm (selection folds 3-4)")
es = ev_c([3, 4]); refm = es.constraint_metrics(LRF)
D = {al: [np.load(f"{RUNS}/{tag(al, 'main', s)}") for s in SEEDS] for al in NAMES}
U = np.vstack([d["archive_F"] for al in NAMES for d in D[al]])
lo_, hi_ = U.min(0), U.max(0)
norm = lambda F: (F - lo_) / np.where(hi_ > lo_, hi_ - lo_, 1)  # noqa: E731
hv = HV(ref_point=np.full(4, 1.1))
nds = NonDominatedSorting()
CK = [100, 200, 500, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]
MR, CV = [], []
for al in NAMES:
    for s, d in zip(SEEDS, D[al]):
        Mx = np.array([es.constraint_metrics(x) for x in d["X"]])
        okk = np.all(Mx[:, :4] <= refm[:4] + 1e-12, axis=1)
        MR.append(dict(algo=al, seed=s, best_disc=100 * (Mx[okk, 4].min() if okk.any() else refm[4]), n_qual=int(okk.sum()),
                       hv=hv(norm(d["F"])), front=len(d["X"]), seconds=float(d["seconds"])))
        AFk = d["archive_F"]
        for c in CK:
            Fc = AFk[:c]
            CV.append(dict(algo=al, seed=s, evals=c, hv=hv(norm(Fc[nds.do(Fc, only_non_dominated_front=True)]))))
MR, CV = pd.DataFrame(MR), pd.DataFrame(CV)
MR.to_csv(f"{OUT}/algos_main.csv", index=False); CV.to_csv(f"{OUT}/convergence.csv", index=False)
FR = {}
for m, better_low in (("best_disc", True), ("hv", False)):
    piv = MR.pivot(index="seed", columns="algo", values=m)[NAMES]
    stat, p = friedmanchisquare(*[piv[a] for a in NAMES])
    rk = np.vstack([rankdata(row if better_low else -row) for row in piv.to_numpy()]).mean(0)
    FR[m] = dict(chi2=stat, p=p, ranks=dict(zip(NAMES, rk)))
    say(f"  Friedman {m}: chi2 = {stat:.1f}, p = {p:.2g}; best mean ranks: " +
        ", ".join(f"{LAB[a]} {r:.1f}" for a, r in sorted(zip(NAMES, rk), key=lambda t: t[1])[:5]))
rho = spearmanr([FR["hv"]["ranks"][a] for a in NAMES], [FR["best_disc"]["ranks"][a] for a in NAMES])
FR["spearman_hv_vs_best_disc"] = dict(rho=float(rho.statistic), p=float(rho.pvalue))
# first tier: hypervolume not different from the best-ranked algorithm (Wilcoxon signed-rank over seeds, Holm, 5%)
piv = MR.pivot(index="seed", columns="algo", values="hv")[NAMES]
best = min(NAMES, key=lambda a: FR["hv"]["ranks"][a])
pw = {a: float(wilcoxon(piv[best], piv[a]).pvalue) for a in NAMES if a != best}
adj, run = {}, 0.0
for i_, a in enumerate(sorted(pw, key=pw.get)):
    run = max(run, min(1.0, pw[a] * (len(pw) - i_))); adj[a] = run
TIER = sorted([best] + [a for a in pw if adj[a] >= 0.05], key=lambda a: FR["hv"]["ranks"][a])
FR["hv"]["holm_p_vs_best"] = adj; FR["hv"]["best"] = best; FR["first_tier"] = TIER
json.dump(FR, open(f"{OUT}/friedman.json", "w"), indent=1)
say(f"  Spearman HV rank vs best-qualifying rank: rho = {rho.statistic:.2f}, p = {rho.pvalue:.2f}")
say("  first tier by hypervolume (Holm-adjusted p vs " + LAB[best] + "): " +
    ", ".join(f"{LAB[a]}" + ("" if a == best else f" ({adj[a]:.2f})") for a in TIER))
for al in NAMES:
    x = MR[MR.algo == al]
    say(f"  {LAB[al]:17s} best qualifying disc median {x.best_disc.median():5.2f} [{x.best_disc.min():5.2f}-{x.best_disc.max():5.2f}]"
        f"  HV median {x.hv.median():.4f}  front {x.front.median():5.0f}  {x.seconds.median():5.1f} s")


# =============================== primary analysis ===============================
say(f"\n== primary analysis: first tier pooled ({', '.join(LAB[a] for a in TIER)}), nested cross-validation")
T_sp, info = nested_tables(TIER)
pd.DataFrame(info).to_csv(f"{OUT}/primary_folds.csv", index=False)
for r in info:
    say(f"  outer {r['outer']}: pooled {r['pooled']}, qualifying {r['qualifying']}, "
        f"{'LR-full kept' if r['lrfull_kept'] else 'selection-fold recall discordance %.1f vs %.1f' % (r['sel_disc'], r['sel_disc_lrfull'])}")
P, res = [], {}
for meas in SOLID_COLS:
    E, C = oof(T_sp, meas)
    df = compare(E, C, analysis="primary", measure=meas)
    P.append(df); res[meas] = df.set_index("metric")
    if meas == "-300 HU":
        E300, C300 = E, C
P = pd.concat(P); P.to_csv(f"{OUT}/primary.csv", index=False)
for _, r in P[P.measure == "-300 HU"].iterrows():
    say(f"  {r.metric:12s} n={r.n:4d}  {r.rule:5.1f} vs {r.comp:5.1f}  {r['diff']:+6.2f} ({r.lo:+6.2f} .. {r.hi:+6.2f})")


def criteria(R, robust_R):
    c = {"recall discordance UB < 0": R.at["recall_disc", "hi"] < 0, "miss UB < +2": R.at["miss", "hi"] < 2,
         "under-triage UB < +2": R.at["under", "hi"] < 2, "FP recall UB < +2": R.at["fp_recall", "hi"] < 2,
         "non-cancer >=3-month UB < +2": R.at["nc_ge3m", "hi"] < 2}
    m5 = ("recall_disc", "miss", "under", "fp_recall", "nc_ge3m")
    same = lambda a, b: np.sign(a) == np.sign(b) or (abs(a) < 1e-9 and abs(b) < 1e-9)  # noqa: E731
    c["robustness"] = all(same(X.at[m, "diff"], R.at[m, "diff"]) for X in robust_R for m in m5)
    return c


crit = criteria(res["-300 HU"], [res["-200 HU"], res["-300 HU / 0.81"]])
for k, v in crit.items():
    say(f"  criterion {k}: {'met' if v else 'not met'}")
say(f"  SUCCESS: {'yes' if all(crit.values()) else 'no'}")
json.dump({k: bool(v) for k, v in crit.items()}, open(f"{OUT}/primary_decision.json", "w"), indent=1)


# level agreement between reads: pooled 4x4 tables of ordered read pairs
def pair_table(ev, g):
    rl = ev.levels(g); M = np.zeros((4, 4))
    for p in range(len(ev.pids)):
        lv = rl[ev.read_pat == p]
        for i in range(len(lv)):
            for j in range(len(lv)):
                if i != j:
                    M[lv[i], lv[j]] += 1
    return M


PT = {"LR-full": sum(pair_table(ev_c([k]), LRF) for k in range(5)),
      "selected": sum(pair_table(ev_c([k]), T_sp[k]) for k in range(5))}
np.savez(f"{OUT}/pair_tables.npz", **{k.replace("-", "_"): v for k, v in PT.items()})
W = (np.subtract.outer(np.arange(4), np.arange(4)) ** 2 / 9)
wk = lambda M: 1 - (M / M.sum() * W).sum() / (np.outer(M.sum(1), M.sum(0)) / M.sum() ** 2 * W).sum()  # noqa: E731


def kappa_counts(ev, g):
    rl = ev.levels(g); Cn = np.zeros((len(ev.pids), 16))
    for p in range(len(ev.pids)):
        lv = rl[ev.read_pat == p]
        for i in range(len(lv)):
            for j in range(len(lv)):
                if i != j:
                    Cn[p, 4 * lv[i] + lv[j]] += 1
    return Cn


def wkappa(c):
    O = c.reshape(-1, 4, 4) / c.sum(-1).reshape(-1, 1, 1)
    Ex = O.sum(2)[:, :, None] * O.sum(1)[:, None, :]
    return 1 - (O.reshape(-1, 16) * W.ravel()).sum(1) / (Ex.reshape(-1, 16) * W.ravel()).sum(1)


KE = np.vstack([kappa_counts(ev_c([k]), T_sp[k]) for k in range(5)])
KC = np.vstack([kappa_counts(ev_c([k]), LRF) for k in range(5)])
strata = np.concatenate([ev_c([k]).cancer for k in range(5)])
rng = np.random.default_rng(0)
idx = np.hstack([ix[rng.integers(0, len(ix), size=(10000, len(ix)))] for ix in (np.flatnonzero(strata == s_) for s_ in (False, True))])
ke, kc = wkappa(KE.sum(0)[None])[0], wkappa(KC.sum(0)[None])[0]
dk = wkappa(KE[idx].sum(1)) - wkappa(KC[idx].sum(1))
same = lambda Mx: np.trace(Mx) / Mx.sum() * 100  # noqa: E731
json.dump(dict(kappa_selected=ke, kappa_lrfull=kc, diff=ke - kc, lo=float(np.percentile(dk, 2.5)), hi=float(np.percentile(dk, 97.5)),
               same_level_selected=same(PT["selected"]), same_level_lrfull=same(PT["LR-full"])),
          open(f"{OUT}/kappa.json", "w"), indent=1)
say(f"  quadratic-weighted kappa: selected {ke:.3f} vs LR-full {kc:.3f}, difference {ke - kc:+.3f} "
    f"({np.percentile(dk, 2.5):+.3f} .. {np.percentile(dk, 97.5):+.3f}); same level {same(PT['selected']):.1f}% vs {same(PT['LR-full']):.1f}%")

# context
A = pd.concat([rates(ev_c([k]), LRA) for k in range(5)])
compare(A, C300, analysis="context LR-A", measure="-300 HU").to_csv(f"{OUT}/context_lra.csv", index=False)
pat = pd.read_csv("data/raw/nlst501/LIDC-annot-NLST501-patients.csv").set_index("pid")
LEVEL = {"1": 0, "2": 0, "3": 1, "4A": 2, "4B": 3, "4X": 3}
six = [p for p in E300.index if p in set(pat[pat.reader1.notna()].index)]
Lr = pat.loc[six, [f"reader{i}" for i in range(1, 7)]].apply(lambda c: c.map(LEVEL)).to_numpy(float)
okr = ~np.isnan(Lr); n_ = okr.sum(1); r_ = ((Lr >= 1) & okr).sum(1)
ctx = dict(n=len(six), readers_own=100 * (r_ * (n_ - r_) / (n_ * (n_ - 1) / 2)).mean(),
           selected=100 * E300.loc[six, "recall_disc"].mean(), lrfull=100 * C300.loc[six, "recall_disc"].mean())
json.dump(ctx, open(f"{OUT}/context_readers.json", "w"), indent=1)
say(f"  readers' own Lung-RADS v1.1 ({ctx['n']} participants): {ctx['readers_own']:.1f}%; selected {ctx['selected']:.1f}%, "
    f"LR-full {ctx['lrfull']:.1f}%")

# =============================== trade-off with the margin ===============================
say("\n== out-of-sample trade-off: selection with a margin on the four constraints (first tier, nested)")
TR = []
for m in (0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 7.5, 10.0):
    T, inf = nested_tables(TIER, margin=m / 100) if m else (T_sp, info)
    E, C = oof(T)
    df = compare(E, C, analysis="trade-off", margin=m)
    df["folds_lrfull"] = sum(r["lrfull_kept"] for r in inf)
    TR.append(df)
    d = df.set_index("metric")
    say(f"  margin {m:4.1f} pp: recall disc {d.at['recall_disc', 'diff']:+6.2f}, miss {d.at['miss', 'diff']:+6.2f}, "
        f"under {d.at['under', 'diff']:+6.2f}, FP recall {d.at['fp_recall', 'diff']:+6.2f}; LR-full kept in "
        f"{df.folds_lrfull.iat[0]} folds")
pd.concat(TR).to_csv(f"{OUT}/tradeoff.csv", index=False)

# =============================== every algorithm, nested ===============================
say("\n== every embedded algorithm through the nested procedure")
AN, AF, TAB = [], [], {}
for al in NAMES:
    T, inf = nested_tables(al)
    TAB[al] = T
    AF += inf
    R = {}
    for meas in SOLID_COLS:
        E, C = oof(T, meas)
        df = compare(E, C, analysis="nested", algo=al, measure=meas)
        AN.append(df); R[meas] = df.set_index("metric")
    c = criteria(R["-300 HU"], [R["-200 HU"], R["-300 HU / 0.81"]])
    d = R["-300 HU"]
    say(f"  {LAB[al]:17s} folds with a table {5 - sum(r['lrfull_kept'] for r in inf)}; recall disc "
        f"{d.at['recall_disc', 'diff']:+5.2f} ({d.at['recall_disc', 'lo']:+5.2f} .. {d.at['recall_disc', 'hi']:+5.2f}); miss "
        f"{d.at['miss', 'diff']:+5.2f} (UB {d.at['miss', 'hi']:+5.2f}); level disc {d.at['level_disc', 'diff']:+5.2f}; "
        f"criteria met {sum(c.values())}/6")
pd.concat(AN).to_csv(f"{OUT}/algos_nested.csv", index=False)
pd.DataFrame(AF).to_csv(f"{OUT}/algos_nested_folds.csv", index=False)

# selection-fold view of the pooled first-tier main-design front (for trade-off scatter plots)
Xm = pooled(TIER, "main")
g_main, Mm = select(Xm, es, LRF)
np.savez(f"{OUT}/main_front_selection.npz", M=Mm, ref=refm, chosen=Mm[np.flatnonzero((Xm == g_main).all(1))[0]])
# all algorithms' pooled main-design fronts on the selection folds: best qualifying recall discordance by algorithm
# =============================== test set, external, automated reading (first tier) ===============================
say("\n== test set (descriptive), first-tier main-design table")
TS = compare(rates(ev_c([-1]), g_main), rates(ev_c([-1]), LRF), analysis="test set")
TS.to_csv(f"{OUT}/test_set.csv", index=False)
for _, r in TS.iterrows():
    say(f"  {r.metric:12s} n={r.n:4d}  {r.rule:5.1f} vs {r.comp:5.1f}  {r['diff']:+6.2f} ({r.lo:+6.2f} .. {r.hi:+6.2f})")


def cluster_ci(values, cluster, n_boot=10000, seed=0):
    v = np.asarray(values, float); u, inv = np.unique(np.asarray(cluster), return_inverse=True)
    s = np.bincount(inv, weights=v, minlength=len(u)); n = np.bincount(inv, minlength=len(u)).astype(float)
    i = np.random.default_rng(seed).integers(0, len(u), size=(n_boot, len(u)))
    bs = s[i].sum(1) / n[i].sum(1)
    return 100 * v.mean(), 100 * np.percentile(bs, 2.5), 100 * np.percentile(bs, 97.5)


TEX = np.array(["solid", "part", "ggo"])


def ext_nodules(p, exam):
    return pd.DataFrame({"pid": exam, "db": "s01", "size": p["size"], "tex": TEX[p["tex"]], "spic": p["spic"],
                         "lobu": p["lobu"], "margin": p["margin"], "spher": p["spher"],
                         "benign_calc": p["bcalc"].astype(bool), "solid": p["size"]})


EX = []


def external(name, L, exam_pid):
    mal = L.groupby("pid").malignant.any()
    ev = Evaluator(L, L[["pid", "db"]].drop_duplicates(), mal, mal.index)
    cl = np.array([exam_pid[e] for e in ev.pids])
    Re, Rc = ev.patient_rates(g_main), ev.patient_rates(LRF)
    for m, grp in (("miss", True), ("under", True), ("fp_recall", False), ("ge3m", False)):
        sel = ev.cancer if grp else ~ev.cancer
        d, lo, hi = cluster_ci((Re[m] - Rc[m])[sel], cl[sel])
        EX.append(dict(dataset=name, metric=m, n=int(sel.sum()), rule=100 * Re[m][sel].mean(), comp=100 * Rc[m][sel].mean(),
                       diff=d, lo=lo, hi=hi))
        say(f"  {name:7s} {m:10s} n={int(sel.sum()):5d} {EX[-1]['rule']:5.1f} vs {EX[-1]['comp']:5.1f}  {d:+6.2f} ({lo:+6.2f} .. {hi:+6.2f})")


say("\n== external datasets, model-read signs, first-tier main-design table vs LR-full")
lx = np.load(f"{SR}/lungx_meta.npz")
L = ext_nodules(dict(np.load(f"{SR}/pred_lungx.npz")), lx["scan"]); L["malignant"] = lx["malignant"].astype(bool)
external("LUNGx", L, {e: e for e in L.pid.unique()})
lu = np.load(f"{SR}/luna25_meta.npz")
csv = pd.read_csv("data/raw/luna25/LUNA25_Public_Training_Development_Data.csv")
base = csv[~csv.PatientID.isin(set(pat.index))].reset_index(drop=True)
meta = base.loc[lu["row"]]; exam = meta.SeriesInstanceUID.to_numpy()
L = ext_nodules(dict(np.load(f"{SR}/pred_luna25.npz")), exam); L["malignant"] = meta.label.to_numpy().astype(bool)
external("LUNA25", L, dict(zip(exam, meta.PatientID.astype(int))))
pd.DataFrame(EX).to_csv(f"{OUT}/external.csv", index=False)

say("\n== automated reading: same level from reader signs and model-read signs (development, out-of-fold reader)")
PR = {}
for f in sorted(glob.glob(f"{SR}/oof_fold*.npz")):
    d = np.load(f)
    for i, rr in enumerate(d["row"]):
        PR[int(rr)] = {"size": float(d["size"][i]), "tex": int(d["tex"][i].argmax()), "spic": int(d["spic"][i].argmax()),
                       "lobu": int(d["lobu"][i].argmax()), "margin": int(d["margin"][i].argmax()),
                       "spher": int(d["spher"][i].argmax()), "bcalc": bool(d["bcalc"][i].argmax())}
AG = []
for k in range(5):
    ids = set(pids_in(fold, [k]))
    rr = [i for i in nod.index if nod.at[i, "pid"] in ids and i in PR]
    R = nod.loc[rr]; Mo = R.copy()
    Mo["size"] = [PR[i]["size"] for i in rr]; Mo["tex"] = TEX[[PR[i]["tex"] for i in rr]]
    for h in ("spic", "lobu", "margin", "spher"):
        Mo[h] = [PR[i][h] for i in rr]
    Mo["benign_calc"] = [PR[i]["bcalc"] for i in rr]
    Mo["solid"] = np.minimum(R["solid"].to_numpy(), Mo["size"].to_numpy())
    e1 = Evaluator(R, reads, cancer, sorted(ids)); e2 = Evaluator(Mo, reads, cancer, sorted(ids))
    for nm, g in (("selected", T_sp[k]), ("LR-full", LRF)):
        a1, a2 = e1.nodule_levels(g), e2.nodule_levels(g)
        AG.append(pd.DataFrame({"rule": nm, "pid": R.pid.to_numpy(), "reader": a1, "model": a2}))
AG = pd.concat(AG)
a = (AG[AG.rule == "selected"].reader == AG[AG.rule == "selected"].model).to_numpy()
b = (AG[AG.rule == "LR-full"].reader == AG[AG.rule == "LR-full"].model).to_numpy()
d, lo, hi = cluster_ci(a.astype(float) - b, AG[AG.rule == "selected"].pid.to_numpy())
say(f"  findings {len(a)}: same level {100 * a.mean():.1f}% (selected) vs {100 * b.mean():.1f}% (LR-full); "
    f"difference {d:+.2f} ({lo:+.2f} .. {hi:+.2f})")
AG.to_csv(f"{OUT}/automated_levels.csv", index=False)
json.dump(dict(n=len(a), selected=100 * a.mean(), lrfull=100 * b.mean(), diff=d, lo=lo, hi=hi),
          open(f"{OUT}/automated_summary.json", "w"), indent=1)

json.dump({"first_tier": TIER, "primary_nested": {str(k): to_json(g) for k, g in enumerate(T_sp)}, "main": to_json(g_main),
           "nested_by_algorithm": {al: {str(k): to_json(g) for k, g in enumerate(TAB[al])} for al in NAMES}},
          open(f"{OUT}/selected_tables.json", "w"), indent=1)
open(f"{OUT}/evaluation.txt", "w").write("\n".join(lines) + "\n")
