"""Sources of recall discordance (descriptive; added after the main results).

Every discordant pair of reads of a participant (one read recalls, the other does not) is attributed to one source, so
that the participant's recall discordance (share of the six pairs that disagree) splits into additive parts:
  detection   the nodule that drives the recall (highest level, then largest) has no finding of the other read nearby
  non-target  the other read recorded it only as a non-target lesion (scar, fibrosis, atelectasis, ...)
  texture     the other read recorded it as a nodule; giving that nodule the recalling read's texture (and solid
              component) already makes it recall
  size        ... and the recalling read's size as well
  signs       ... and the recalling read's signs, shape and calcification as well
Findings of two reads are the same lesion if their centres lie within max(10 mm, mean of the two diameters); 5 and 15 mm
are reported as sensitivity analyses. Coordinates: in-plane pixels x reconstruction diameter / 512, slices x
reconstruction interval (slice thickness where missing).

    python scripts/decompose_discordance.py        -> runs/discordance_sources.txt / .csv
"""
import json, os, sys
import numpy as np
import pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from data import load, pids_in, design_folds                                             # noqa: E402
from search import Evaluator, lrfull_genome, select                                     # noqa: E402

ROOT = os.path.join(os.path.dirname(__file__), "..")
RUNS = os.environ.get("RUNS", "runs/search")
SRC = ("detection", "non-target", "texture", "size", "signs")
nod, reads, cancer, fold = load("-300 HU")
ann = pd.read_csv(os.path.join(ROOT, "data/raw/nlst501/LIDC-annot-NLST501-annotations.csv"))
ser = pd.read_csv(os.path.join(ROOT, "data/raw/nlst501/LIDC-annot-NLST501-series.csv")).set_index("series_uid")
pix = ann.series_uid.map(ser.reconstruction_diameter / 512.0)
dz = ann.series_uid.map(ser.reconinterval.fillna(ser.reconthickness))
ann = ann.assign(X=ann.location_x * pix, Y=ann.location_y * pix, Z=ann.location_z * dz)
assert ann.loc[ann.finding_type.notna(), ["X", "Y", "Z"]].notna().all().all()   # two rows are empty reads
key = ["pid", "db", "series_uid", "finding_id"]
nod = nod.merge(ann[key + ["X", "Y", "Z"]], on=key, how="left").reset_index(drop=True)
ntl = ann[ann.finding_type == "NTL"][["pid", "db", "X", "Y", "Z"]]
lines, rows = [], []


def say(s=""):
    print(s, flush=True); lines.append(s)


def levels_of(rows_, g):
    """Management level of each row of a nodule table under table g (each row as its own read)."""
    r = rows_.reset_index(drop=True).assign(db=[f"cf{i}" for i in range(len(rows_))], pid=0)
    return Evaluator(r, r[["pid", "db"]], {0: False}, [0]).nodule_levels(g)


PAIRS = []


def decompose(g, pids, tol=None, log=False):
    """Per participant: contribution of each source to recall discordance (share of the six pairs)."""
    ev = Evaluator(nod, reads, cancer, pids)
    sub = nod[nod.pid.isin(set(pids))].reset_index(drop=True)          # same row order as the evaluator
    lvl = ev.nodule_levels(g); rl = ev.levels(g)
    rkeys = list(ev.read_key)                                            # read index -> (pid, db)
    out = np.zeros((len(ev.pids), len(SRC)))
    by_read = {r: np.flatnonzero(ev.read_idx == r) for r in range(ev.n_reads)}
    ntl_by = {k: v[["X", "Y", "Z"]].to_numpy() for k, v in ntl[ntl.pid.isin(set(pids))].groupby(["pid", "db"])}
    for p in range(len(ev.pids)):
        rs = np.flatnonzero(ev.read_pat == p)
        npairs = len(rs) * (len(rs) - 1) / 2
        for a in rs:
            if rl[a] < 1:
                continue
            ia = by_read[a]
            f = ia[np.lexsort((-sub["size"].to_numpy()[ia], -lvl[ia]))[0]]           # driving finding of read a
            pf = sub.loc[f, ["X", "Y", "Z"]].to_numpy(float)
            for b in rs:
                if rl[b] >= 1:
                    continue
                ib = by_read[b]
                lim = lambda s2: tol if tol else max(10.0, (sub.at[f, "size"] + s2) / 2)  # noqa: E731
                cand = [(np.linalg.norm(sub.loc[j, ["X", "Y", "Z"]].to_numpy(float) - pf), j) for j in ib]
                cand = [(d, j) for d, j in cand if d <= lim(sub.at[j, "size"])]
                if not cand:
                    nt = ntl_by.get(rkeys[b], np.empty((0, 3)))
                    near = len(nt) and (np.linalg.norm(nt - pf, axis=1) <= (tol if tol else max(10.0, sub.at[f, "size"]))).any()
                    src = 1 if near else 0
                else:
                    j = min(cand)[1]
                    cf = sub.loc[[j]].copy()
                    src = None
                    for k, cols in ((2, ["tex", "solid"]), (3, ["size"]), (4, ["spic", "lobu", "margin", "spher", "benign_calc"])):
                        cf[cols] = sub.loc[[f], cols].to_numpy()
                        if levels_of(cf, g)[0] >= 1:
                            src = k; break
                    assert src is not None
                out[p, src] += 1 / npairs
                if log:
                    j_ = min(cand)[1] if cand else None
                    PAIRS.append(dict(pid=ev.pids[p], cancer=bool(ev.cancer[p]), source=SRC[src],
                                      size_recall=sub.at[f, "size"], tex_recall=sub.at[f, "tex"], level_recall=int(lvl[f]),
                                      size_other=np.nan if j_ is None else sub.at[j_, "size"],
                                      tex_other=None if j_ is None else sub.at[j_, "tex"]))
    return pd.DataFrame(out, columns=SRC, index=ev.pids).assign(cancer=ev.cancer)


def report(D, label):
    tot = D[list(SRC)].sum(axis=1).mean()
    say(f"  {label:44s} recall discordance {100 * tot:5.1f}%  = " + " + ".join(
        f"{s} {100 * D[s].mean():.1f}" for s in SRC) + "  (shares: " + ", ".join(
        f"{s} {100 * D[s].mean() / tot:.0f}%" for s in SRC) + ")")
    rows.append(dict(analysis=label, total=100 * tot, **{s: 100 * D[s].mean() for s in SRC}))


LRF = lrfull_genome()
dev = pids_in(fold, range(5)); allp = pids_in(fold, list(range(5)) + [-1])
say("== sources of recall discordance under LR-full (percentage points of recall discordance)")
for nm, P in (("all 501 participants", allp), ("development set (401)", dev), ("test set (100)", pids_in(fold, [-1]))):
    report(decompose(LRF, P), f"LR-full, {nm}")
D = decompose(LRF, allp, log=True)
pd.DataFrame(PAIRS).to_csv("runs/discordance_pairs_lrfull.csv", index=False)
for c, nm in ((True, "cancer"), (False, "non-cancer")):
    report(D[D.cancer == c], f"LR-full, all 501, {nm}")
for t in (5.0, 15.0):
    report(decompose(LRF, allp, tol=t), f"LR-full, all 501, matching within {t:g} mm")

TIER = json.load(open("runs/attune/friedman.json"))["first_tier"]        # written by evaluate_attune.py
say(f"\n== selected tables of the nested procedure (first tier pooled: {', '.join(TIER)}), out-of-fold, vs LR-full on the same folds")
E, C = [], []
for k in range(5):
    _, sel_f, _ = design_folds("nested", k)
    X = np.unique(np.vstack([np.load(f"{RUNS}/nested{k}_{a}_s{s}.npz")["X"] for a in TIER for s in range(10)]), axis=0)
    g, _ = select(X, Evaluator(nod, reads, cancer, pids_in(fold, sel_f)), LRF)
    P = pids_in(fold, [k])
    E.append(decompose(LRF if g is None else g, P)); C.append(decompose(LRF, P))
report(pd.concat(C), "LR-full, development out-of-fold")
report(pd.concat(E), "selected tables, development out-of-fold")
os.makedirs("runs", exist_ok=True)
open("runs/discordance_sources.txt", "w").write("\n".join(lines) + "\n")
pd.DataFrame(rows).round(3).to_csv("runs/discordance_sources.csv", index=False)
