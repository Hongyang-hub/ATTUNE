#!/bin/bash
# All searches of the paper: 20 algorithms x (main design + 5 nested outer folds) x seeds 0-9 = 1,200 runs
# (the main-design runs coincide with those of outer fold 3 in code numbering, fold 4 in the paper).
# Usage: bash scripts/run_searches.sh [number of parallel processes, default 8]
cd "$(dirname "$0")/.."
NPROC=${1:-8}
ALGOS="spea2 nsga2 agemoea2 tnsga2 prvnsga2 pdmaoea nsga3 rvea nrvmoea moead moeadde ibea smsemoa twoarch2 maoeahap mopsocd cmopso smpso admopso gde3"
mkdir -p logs
for al in $ALGOS; do for s in $(seq 0 9); do
  echo "--design main --seed $s --algo $al"
  for k in 0 1 2 3 4; do echo "--design nested --outer $k --seed $s --algo $al"; done
done; done | xargs -P "$NPROC" -L 1 sh -c 'OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 python scripts/run_search.py $0 "$@" >> logs/searches.log 2>&1 || echo "FAILED $0 $@" >> logs/searches.log'
grep -c FAILED logs/searches.log || true
