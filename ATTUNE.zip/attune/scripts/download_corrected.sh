#!/bin/bash
# 24 series corrected by the dataset authors (annotations refer to these UIDs); TCIA NBIA API.
set -e
tail -n +2 data/raw/nlst501/LIDC-annot-NLST501-correction.csv | while IFS=, read -r orig corr pid rest; do
  d=data/raw/nlst501/dicom/$pid/$corr; mkdir -p $d
  [ -n "$(ls -A $d)" ] && continue
  curl -s --ciphers DEFAULT@SECLEVEL=1 --max-time 600 -o $d.zip \
    "https://services.cancerimagingarchive.net/nbia-api/services/v1/getImage?SeriesInstanceUID=$corr"
  unzip -q -o $d.zip -d $d && rm $d.zip
  echo "$pid $(ls $d | wc -l)"
done
