"""Download the NLST501 CT series from NCI Imaging Data Commons (public AWS bucket); only needed to recompute the
solid component (scripts/solid_component.py). The 24 series corrected by the dataset authors are fetched by
scripts/download_corrected.sh.
"""
from pathlib import Path

from idc_index import IDCClient

uids = [l.strip() for l in open("data/raw/nlst501/source-manifest-LIDC-annot-NLST501.tcia") if l.strip().startswith("1.")]
out = Path("data/raw/nlst501/dicom")
out.mkdir(parents=True, exist_ok=True)
IDCClient().download_from_selection(seriesInstanceUID=uids, downloadDir=str(out), dirTemplate="%PatientID/%SeriesInstanceUID",
                                    quiet=False, show_progress_bar=False)
print("downloaded", len(uids), "series")
