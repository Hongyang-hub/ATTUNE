"""Automated solid-component measurement for NLST501 findings with a DICOM SEG mask (label-free).
For every segmented finding of every read, the mask is mapped to the CT grid through physical coordinates; on each axial
slice the largest connected region of mask voxels above an attenuation threshold is taken as the solid component, and its
mean diameter, (long axis + perpendicular short axis) / 2 as in Lung-RADS v2022, is measured; the slice with the longest
axis gives the solid-component size. The whole mask is measured the same way as a check against the reported diameter.
Thresholds: -300 HU (primary) and -200 HU. Output: data/derived/solid_component.csv
"""
import glob, multiprocessing as mp, os, sys
import numpy as np
import pandas as pd

THRS = (-300, -200)


def mean_diameter(rc_mm):
    """(long axis + perpendicular short axis)/2 of a 2-D point set in mm; returns (mean, long, short)."""
    from scipy.spatial import ConvexHull
    if len(rc_mm) == 0:
        return 0.0, 0.0, 0.0
    if len(rc_mm) < 3:
        return 0.5, 0.5, 0.5
    try:
        h = rc_mm[ConvexHull(rc_mm).vertices]
    except Exception:  # noqa: BLE001  (collinear points)
        h = rc_mm
    d = np.sqrt(((h[:, None] - h[None]) ** 2).sum(-1))
    i, j = np.unravel_index(d.argmax(), d.shape)
    long_ = d[i, j]
    u = (h[j] - h[i]) / (long_ + 1e-9); v = np.array([-u[1], u[0]])
    proj = rc_mm @ v
    short = proj.max() - proj.min()
    return (long_ + short) / 2, long_, short


def slice_size(mask2d, sp):
    """largest connected component of a 2-D mask -> mean diameter in mm (pixel extent included)."""
    from scipy import ndimage
    if not mask2d.any():
        return 0.0, 0.0
    lab, n = ndimage.label(mask2d)
    k = np.bincount(lab.ravel())[1:].argmax() + 1
    r, c = np.nonzero(lab == k)
    pts = np.column_stack([r * sp[1], c * sp[0]])
    m, lg, sh = mean_diameter(pts)
    ps = (sp[0] + sp[1]) / 2                  # extent includes the pixel width on both axes
    return m + ps, lg + ps


TMP = os.environ.get("SEG_TMP", "/tmp/solid_component_seg")
NBIA = "https://services.cancerimagingarchive.net/nbia-api/services/v1"


def fetch_seg(uid, d):
    """download one SEG series from TCIA into d (local scratch); returns the file path or None."""
    import io, subprocess, zipfile
    os.makedirs(d, exist_ok=True)
    for _ in range(3):
        r = subprocess.run(["curl", "-s", "--ciphers", "DEFAULT@SECLEVEL=1", "--max-time", "600", f"{NBIA}/getImage?SeriesInstanceUID={uid}"],
                           capture_output=True)
        try:
            with zipfile.ZipFile(io.BytesIO(r.stdout)) as z:
                for n in z.namelist():
                    if n.endswith(".dcm"):
                        f = os.path.join(d, uid + ".dcm"); open(f, "wb").write(z.read(n)); return f
        except Exception:  # noqa: BLE001
            continue
    return None


def work(arg):
    pid, extra = arg if isinstance(arg, tuple) else (arg, [])
    os.environ["OMP_NUM_THREADS"] = "1"
    import pydicom, SimpleITK as sitk
    sitk.ProcessObject.SetGlobalDefaultNumberOfThreads(1)
    sys.path.insert(0, "src")
    from ct import load_series
    out, cache = [], {}
    local = glob.glob(f"data/raw/nlst501/seg/{pid}/*.dcm")
    have = {os.path.basename(f)[:-4] for f in local}
    tmpd = os.path.join(TMP, str(pid)); fetched = []
    for uid in extra:
        if uid not in have:
            f = fetch_seg(uid, tmpd)
            if f:
                fetched.append(f)
    for f in local + fetched:
        ds = pydicom.dcmread(f)
        db = str(ds.ClinicalTrialSeriesID)
        suid = ds.ReferencedSeriesSequence[0].SeriesInstanceUID if "ReferencedSeriesSequence" in ds else None
        if suid is None or not os.path.isdir(f"data/raw/nlst501/dicom/{pid}/{suid}"):
            continue
        if suid not in cache:
            img = load_series(f"data/raw/nlst501/dicom/{pid}/{suid}")
            cache[suid] = (img, sitk.GetArrayFromImage(img).astype(np.float32))
        img, vol = cache[suid]
        O = np.array(img.GetOrigin()); D = np.array(img.GetDirection()).reshape(3, 3); S = np.array(img.GetSpacing())
        labels = {int(s.SegmentNumber): str(s.SegmentLabel) for s in ds.SegmentSequence}
        px = ds.pixel_array
        if px.ndim == 2:
            px = px[None]
        pos = np.array([[float(v) for v in fr.PlanePositionSequence[0].ImagePositionPatient] for fr in ds.PerFrameFunctionalGroupsSequence])
        seg = np.array([int(fr.SegmentIdentificationSequence[0].ReferencedSegmentNumber) for fr in ds.PerFrameFunctionalGroupsSequence])
        ori = [float(v) for v in ds.SharedFunctionalGroupsSequence[0].PlaneOrientationSequence[0].ImageOrientationPatient]
        sp = [float(v) for v in ds.SharedFunctionalGroupsSequence[0].PixelMeasuresSequence[0].PixelSpacing]
        rowv, colv = np.array(ori[:3]), np.array(ori[3:])
        for sn, lab in labels.items():
            if not lab.startswith("finding_id"):
                continue
            fid = int(lab.split()[-1]); idx = np.flatnonzero(seg == sn)
            vox = []
            for i in idx:
                r, c = np.nonzero(px[i])
                if len(r) == 0:
                    continue
                P = pos[i][None, :] + np.outer(c, rowv) * sp[1] + np.outer(r, colv) * sp[0]
                ijk = np.rint(((P - O) @ D) / S).astype(int)            # (x, y, z) index
                vox.append(ijk)
            if not vox:
                continue
            V = np.unique(np.vstack(vox), axis=0)
            ok = (V >= 0).all(1) & (V < np.array(img.GetSize())).all(1)
            V = V[ok]
            if len(V) == 0:
                continue
            hu = vol[V[:, 2], V[:, 1], V[:, 0]]
            rec = dict(pid=pid, db=db, series_uid=suid, finding_id=fid, n_vox=len(V), hu_mean=float(hu.mean()),
                       hu_p90=float(np.percentile(hu, 90)), frac_300=float((hu > -300).mean()), frac_200=float((hu > -200).mean()))
            best = {"total": (0.0, 0.0), **{t: (0.0, 0.0) for t in THRS}}
            for z in np.unique(V[:, 2]):
                Vz = V[V[:, 2] == z]
                x0, y0 = Vz[:, 0].min(), Vz[:, 1].min()
                m2 = np.zeros((Vz[:, 1].max() - y0 + 1, Vz[:, 0].max() - x0 + 1), bool)
                m2[Vz[:, 1] - y0, Vz[:, 0] - x0] = True
                hz = vol[z, y0:y0 + m2.shape[0], x0:x0 + m2.shape[1]]
                for key, mk in (("total", m2), *((t, m2 & (hz > t)) for t in THRS)):
                    md, lg = slice_size(mk, S)
                    if lg > best[key][1]:
                        best[key] = (md, lg)
            rec["total_mean_mm"], rec["total_long_mm"] = best["total"]
            for t in THRS:
                rec[f"solid{-t}_mean_mm"], rec[f"solid{-t}_long_mm"] = best[t]
            out.append(rec)
    for f in fetched:
        os.remove(f)
    return out


def main():
    idx = pd.read_csv("data/raw/nlst501/seg/seg_index.csv").dropna(subset=["pid"])
    idx["pid"] = idx.pid.astype(int)
    by_pid = idx.groupby("pid").seg_uid.apply(list).to_dict()       # all SEG series (one per read) per patient
    pids = sorted(by_pid)
    if len(sys.argv) > 1:
        pids = pids[: int(sys.argv[1])]
    with mp.get_context("spawn").Pool(int(os.environ.get("NPROC", 12))) as pool:
        rows = [r for res in pool.imap_unordered(work, [(p, by_pid[p]) for p in pids]) for r in res]
    s = pd.DataFrame(rows)
    ann = pd.read_csv("data/raw/nlst501/LIDC-annot-NLST501-annotations.csv")
    m = s.merge(ann[["pid", "db", "series_uid", "finding_id", "finding_type", "tl_texture", "reported_measure"]], on=["pid", "db", "series_uid", "finding_id"], how="left")
    m.to_csv("data/derived/solid_component.csv", index=False)
    print(f"{len(m)} segmented findings measured; matched to the annotation table: {m.reported_measure.notna().sum()}")


if __name__ == "__main__":
    main()
