#!/bin/bash
# Reproduces the results of the paper from the NLST501 tables and the derived data in data/derived/.
set -e
cd "$(dirname "$0")"
bash scripts/run_searches.sh "${1:-8}"            # runs/search/*.npz
REQUIRE_ALL=1 python scripts/evaluate_attune.py   # runs/attune/*
python scripts/decompose_discordance.py           # runs/discordance_sources.*
