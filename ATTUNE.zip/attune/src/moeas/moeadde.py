"""MOEA/D-DE, implemented from

    H. Li, Q. Zhang. Multiobjective Optimization Problems With Complicated Pareto Sets, MOEA/D and NSGA-II.
    IEEE Transactions on Evolutionary Computation 13(2):284-302, 2009. doi:10.1109/TEVC.2008.925798

Section III-A (Steps 1-3, DE operator (6), polynomial mutation (7)) with the settings of Section IV-A:
CR = 1.0, F = 0.5, eta = 20, p_m = 1/n, T = 20, delta = 0.9, n_r = 2, Tchebycheff decomposition (5).
The weight vectors are the ref_dirs passed in (the paper uses a simplex lattice, Section IV-A item 4).
Step 2.3 draws the new value uniformly between the parent x^i and the violated bound (reset="parent"; the reading that
reproduces Table II, see the doc); "uniform" (whole range) and "clip" exist for validation only, as does zero_weight.
One generation = Step 2 for i = 1..N: one offspring per subproblem, evaluated before the next subproblem is processed,
so every generation evaluates exactly N offspring.
"""
import numpy as np
from scipy.spatial.distance import cdist

from pymoo.algorithms.base.genetic import GeneticAlgorithm
from pymoo.core.algorithm import LoopwiseAlgorithm
from pymoo.core.duplicate import NoDuplicateElimination
from pymoo.core.population import Population
from pymoo.util.display.multi import MultiObjectiveOutput

CR, F_DE = 1.0, 0.5            # Section IV-A, item 1
ETA_M = 20.0                   # Section IV-A, item 1; p_m = 1/n
T_NEIGH, DELTA, N_R = 20, 0.9, 2   # Section IV-A, item 6


def tchebycheff(F, lam, z):
    """g(x | lambda, z) = max_i lambda_i |f_i(x) - z_i|, eq. (5); F (k, m) or (m,), lam (k, m) or (m,)."""
    return (np.abs(np.asarray(F) - z) * lam).max(axis=-1)


def de_operator(x1, x2, x3, cr, f, rnd):
    """Eq. (6): ybar_k = x1_k + F (x2_k - x3_k) with probability CR, else x1_k. rnd: uniform numbers, one per k."""
    return np.where(rnd < cr, x1 + f * (x2 - x3), x1)


def polynomial_mutation(y, xl, xu, eta, pm, rnd_apply, rnd_sigma):
    """Eq. (7): y_k = ybar_k + sigma_k (b_k - a_k) with probability p_m, where
    sigma_k = (2 rand)^(1/(eta+1)) - 1 if rand < 0.5 else 1 - (2 - 2 rand)^(1/(eta+1))."""
    sigma = np.where(rnd_sigma < 0.5, (2.0 * rnd_sigma) ** (1.0 / (eta + 1.0)) - 1.0,
                     1.0 - (2.0 - 2.0 * rnd_sigma) ** (1.0 / (eta + 1.0)))
    return np.where(rnd_apply < pm, y + sigma * (xu - xl), y)


def random_reset(y, xl, xu, rnd, parent=None):
    """Step 2.3: an element out of the boundary is reset to a randomly selected value inside the boundary.
    The paper does not give the distribution. With `parent` (x^{r1} = x^i), the value is drawn uniformly between the
    parent's value and the violated bound, as in the authors' released MOEA/D-DE code (default here); without it, uniformly over the whole range [a_k, b_k]."""
    if parent is None:
        return np.where((y < xl) | (y > xu), xl + rnd * (xu - xl), y)
    return np.where(y < xl, xl + rnd * (parent - xl), np.where(y > xu, xu - rnd * (xu - parent), y))


def neighbourhoods(W, T):
    """Step 1.1: indices of the T closest weight vectors (Euclidean) to each weight vector (itself included)."""
    return np.argsort(cdist(W, W), axis=1, kind="stable")[:, :T]


def replace(FV_pop, f_child, W, z, P, n_r, order):
    """Step 2.5: visit P in the random order `order` (a permutation of P) and replace x^j by the child if
    g(y | lambda^j, z) <= g(x^j | lambda^j, z), at most n_r times. Returns the replaced indices."""
    replaced = []
    for j in np.asarray(P)[order]:
        if len(replaced) >= n_r:
            break
        if tchebycheff(f_child, W[j], z) <= tchebycheff(FV_pop[j], W[j], z):
            replaced.append(int(j))
    return replaced


class MOEADDE(LoopwiseAlgorithm, GeneticAlgorithm):
    def __init__(self, ref_dirs, sampling=None, repair=None, T=T_NEIGH, delta=DELTA, n_r=N_R, CR=CR, F=F_DE,
                 eta_m=ETA_M, pm=None, reset="parent", zero_weight=None, output=MultiObjectiveOutput(), **kwargs):
        self.ref_dirs = np.asarray(ref_dirs, dtype=float)
        # weights used in g (eq. 5); zero_weight=None keeps zero components as they are (lambda_i >= 0, the paper);
        # a number replaces them (the floor used by the authors' and jMetal's code) - optional
        self.W = self.ref_dirs if zero_weight is None else np.where(self.ref_dirs == 0, zero_weight, self.ref_dirs)
        self.T, self.delta, self.n_r, self.CR, self.F, self.eta_m, self.pm = T, delta, n_r, CR, F, eta_m, pm
        assert reset in ("parent", "uniform", "clip")       # "clip": jMetal/Platypus behavior
        self.reset = reset
        super().__init__(pop_size=len(self.ref_dirs), sampling=sampling, repair=repair,
                         eliminate_duplicates=NoDuplicateElimination(), output=output,
                         advance_after_initialization=False, **kwargs)

    def _setup(self, problem, **kwargs):
        assert not problem.has_constraints(), "MOEA/D-DE here is for unconstrained problems"
        assert self.ref_dirs.shape[1] == problem.n_obj
        self.B = neighbourhoods(self.ref_dirs, self.T)                       # Step 1.1
        self.xl, self.xu = (np.asarray(b, dtype=float) for b in problem.bounds())
        if self.pm is None:
            self.pm = 1.0 / problem.n_var                                     # Section IV-A: p_m = 1/n

    def _initialize_advance(self, infills=None, **kwargs):
        super()._initialize_advance(infills, **kwargs)
        assert len(self.pop) == len(self.ref_dirs), "the initial population must have one solution per weight vector"
        self.z = self.pop.get("F").min(axis=0)                               # Step 1.3

    def _next(self):
        rs, N, n = self.random_state, len(self.ref_dirs), self.problem.n_var
        X, FV = self.pop.get("X").astype(float), self.pop.get("F")
        for i in range(N):                                                   # Step 2: for i = 1, ..., N
            # Step 2.1: mating/update range
            P = self.B[i] if rs.random() < self.delta else np.arange(N)
            # Step 2.2: r1 = i, r2 != r3 drawn at random from P; DE (6) then polynomial mutation (7)
            r2, r3 = rs.choice(P, 2, replace=False)
            ybar = de_operator(X[i], X[r2], X[r3], self.CR, self.F, rs.random(n))
            y = polynomial_mutation(ybar, self.xl, self.xu, self.eta_m, self.pm, rs.random(n), rs.random(n))
            # Step 2.3: repair out-of-bound elements, then the problem's own repair
            if self.reset == "clip":
                y = np.clip(y, self.xl, self.xu)
            else:
                y = random_reset(y, self.xl, self.xu, rs.random(n), X[i] if self.reset == "parent" else None)
            off = self.repair(self.problem, Population.new(X=y[None, :]), random_state=rs)
            off = yield off                                                  # one evaluation
            f = off.get("F")[0]
            self.z = np.minimum(self.z, f)                                   # Step 2.4
            # Step 2.5: replacement with at most n_r solutions, picked at random from P
            for j in replace(FV, f, self.W, self.z, P, self.n_r, rs.permutation(len(P))):
                self.pop[j] = off[0]
                X[j], FV[j] = off[0].X, f


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs):
    """crossover/mutation (SBX/PM) are not used: MOEA/D-DE has its own DE operator and polynomial mutation."""
    assert len(ref_dirs) == pop_size, "MOEA/D-DE has one subproblem per weight vector"
    return MOEADDE(ref_dirs=ref_dirs, sampling=sampling, repair=repair)
