"""NRV-MOEA: adaptive normal reference vector guided MOEA (Hua, Liu & Hao, Complex & Intelligent Systems 10:3709-3726,
2024, doi:10.1007/s40747-024-01353-y), implemented from the paper for pymoo 0.6.2.

Per generation (Algorithm 1 of the paper):
  Arc <- UpdateArchive(Arc, P)                  epsilon-indicator archive (non-dominated, I_eps+ fitness truncation to N)
  Q   <- Reproduction(P u Arc, N)               uniform random mating from P u Arc, SBX + polynomial mutation
  Fu  <- first fronts of P u Q until |Fu| >= N  fast non-dominated sorting
  if |Fu| > N: normalise with b_min of Fu and s = b_max - b_min refreshed every fr*MaxG generations, map the last front
       F_l onto the hyperplane through the archive's extreme individuals along its normal (Eq. 1), Ward clustering of
       the mapped points into N - |F_1 u ... u F_(l-1)| clusters, keep from each cluster the member with the smallest
       d = d1 - d2 (Algorithm 3).
The final solution set is the last population P (section "The framework").
"""
import numpy as np

from pymoo.algorithms.base.genetic import GeneticAlgorithm
from pymoo.core.duplicate import NoDuplicateElimination
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.core.population import Population
from pymoo.core.selection import Selection
from pymoo.termination.max_eval import MaximumFunctionCallTermination
from pymoo.termination.max_gen import MaximumGenerationTermination
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
from scipy.cluster.hierarchy import linkage

FR = 0.1        # frequency of the normalisation-scale update, fr = 0.1 (section "The framework")
KAPPA = 0.05    # fitness scaling factor of the epsilon-indicator archive (IBEA/Two_Arch2 default; not given in the paper)
S_ZERO = 1e-5   # normalisation scale used for an objective whose range s is zero (not given in the paper; PlatEMO code)


# ----------------------------------------------------------------------------------------------- components
def ward_clusters(Y, k):
    """Bottom-up hierarchical clustering with Ward's linkage (Euclidean) of the rows of Y into exactly k clusters, i.e.
    the partition at layer k of the dendrogram (labels 0..k-1). scipy's fcluster(maxclust) can return fewer than k
    clusters when merge heights tie, so the first n-k merges of the linkage are replayed instead."""
    n = len(Y)
    if k >= n:
        return np.arange(n)
    if k <= 1:
        return np.zeros(n, dtype=int)
    Z = linkage(Y, method="ward", metric="euclidean")
    parent = np.arange(2 * n - 1)

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for i in range(n - k):                       # the first n-k merges leave exactly k clusters
        a, b = int(Z[i, 0]), int(Z[i, 1])
        parent[find(a)] = n + i
        parent[find(b)] = n + i
    roots = np.array([find(i) for i in range(n)])
    _, lab = np.unique(roots, return_inverse=True)
    return lab


def extreme_points(X):
    """Indices of the extreme individuals: for each objective the individual with the maximum value; when it is already
    the extreme of an earlier objective the next largest is taken, so that m distinct points span the hyperplane."""
    order = np.argsort(-X, axis=0, kind="stable")
    E = []
    for j in range(X.shape[1]):
        k = 0
        while k < len(X) - 1 and order[k, j] in E:
            k += 1
        E.append(order[k, j])
    return np.array(E)


def hyperplane(E, positive=True):
    """Hyperplane A.x + D = 0 through the m extreme points (rows of E), written with D = -1 (A = E^-1 1).
    Fallback to the normal (1,...,1) when the extreme points do not define a hyperplane (singular system) or, with
    positive=True, when the normal has a non-positive component: the paper's sign rule for d2 (Algorithm 3, line 8,
    P - mP < 0 <=> the individual lies on the ideal-point side) presupposes a normal pointing from the ideal towards the
    nadir point. D only shifts all mapped points by one vector and all d2 by one constant, so it never changes the
    clustering or the selection."""
    m = E.shape[1]
    try:
        A = np.linalg.solve(E, np.ones(m))
        ok = bool(np.all(np.isfinite(A))) and (bool(np.all(A > 1e-12)) or not positive)
    except np.linalg.LinAlgError:
        ok = False
    if not ok:
        A = np.ones(m)
    return A, -1.0


def map_to_hyperplane(B, A, D):
    """Eq. (1): p = b + A t, t = -(A.b + D) / |A|^2 (the foot of the normal through b on the hyperplane)."""
    t = -(B @ A + D) / (A @ A)
    return B + t[:, None] * A[None, :]


def nrv_select(FlN, A, D, labels, n_clusters):
    """Algorithm 3 on the normalised last front FlN: for each cluster the index of the member with the smallest
    d = d1 - d2, where d1 = |mP - C| is the distance of the individual to the normal vector through the cluster centre C
    (Eq. 2, mean of the mapped members) and d2 = |P - mP| is its distance to the hyperplane, positive on the ideal-point
    side and negative on the nadir side."""
    mP = map_to_hyperplane(FlN, A, D)
    d2 = -(FlN @ A + D) / np.linalg.norm(A)       # = +|P - mP| when A.P + D < 0 (P - mP = -tA < 0), else -|P - mP|
    chosen = []
    for c in range(n_clusters):
        idx = np.flatnonzero(labels == c)
        C = mP[idx].mean(axis=0)                  # Eq. (2)
        d1 = np.linalg.norm(mP[idx] - C, axis=1)
        chosen.append(idx[np.argmin(d1 - d2[idx])])
    return np.array(chosen, dtype=int)


def eps_fitness_truncate(F, n, kappa=KAPPA):
    """Epsilon-indicator truncation (IBEA, as used for the convergence archive of Two_Arch2 and the archive of
    RVEA-iGNG [22]): objectives normalised to [0,1] over the set, I(a,b) = max_i (a_i - b_i) (additive epsilon),
    fitness(b) = sum_{a != b} -exp(-I(a,b) / (c kappa)), c = max |I|; the solution with the lowest fitness is deleted
    one at a time and the fitness of the others updated. Returns the sorted indices of the n kept rows."""
    F = np.asarray(F, float)
    lo, hi = F.min(axis=0), F.max(axis=0)
    Fn = (F - lo) / np.where(hi - lo > 0, hi - lo, 1.0)
    I = np.max(Fn[:, None, :] - Fn[None, :, :], axis=2)        # I[a, b] = I_eps+(a, b)
    c = np.max(np.abs(I))
    c = c if c > 0 else 1.0
    E = np.exp(-I / (c * kappa))
    fit = -(E.sum(axis=0) - np.diag(E))                          # fit[b] = sum_{a != b} -exp(-I(a,b)/(c kappa))
    alive = np.ones(len(F), dtype=bool)
    while alive.sum() > n:
        cand = np.flatnonzero(alive)
        w = cand[np.argmin(fit[cand])]
        alive[w] = False
        fit += E[w]                                              # remove w's contribution to every b
    return np.flatnonzero(alive)


def update_archive(F, n):
    """Archive management (section "Archive management mechanism"): the non-dominated solutions of Pc u Arc (one copy
    of each objective vector); if more than n, delete by the epsilon-based fitness. Returns indices into F."""
    nd = np.sort(NonDominatedSorting().do(F, only_non_dominated_front=True))
    _, first = np.unique(F[nd], axis=0, return_index=True)
    nd = nd[np.sort(first)]
    if len(nd) > n:
        nd = nd[eps_fitness_truncate(F[nd], n)]
    return nd


class UniformRandomSelection(Selection):
    """Parents drawn uniformly at random with replacement from P u Arc (the paper specifies no mating selection)."""

    def _do(self, _, pop, n_select, n_parents, random_state=None, **kwargs):
        return random_state.integers(0, len(pop), size=(n_select, n_parents))


# ----------------------------------------------------------------------------------------------- algorithm
class NRVMOEA(GeneticAlgorithm):
    def __init__(self, pop_size=100, sampling=None, crossover=None, mutation=None, repair=None, fr=FR, max_gen=None,
                 positive_plane=True, output="population", **kwargs):
        super().__init__(pop_size=pop_size, sampling=FloatRandomSampling() if sampling is None else sampling,
                         selection=UniformRandomSelection(), crossover=crossover, mutation=mutation, survival=None,
                         repair=repair, eliminate_duplicates=NoDuplicateElimination(),
                         advance_after_initial_infill=False, **kwargs)
        self.fr, self.max_gen_user, self.positive_plane, self.output = fr, max_gen, positive_plane, output
        self.arc = None
        self.scale = None
        self.next_refresh = 0
        self.gen = 0

    def _setup(self, problem, **kwargs):
        # MaxG of the paper: generations after the initial population (budget / N for an evaluation budget)
        t = self.termination
        if self.max_gen_user is not None:
            mg = self.max_gen_user
        elif isinstance(t, MaximumFunctionCallTermination) and t.n_max_evals is not None:
            mg = (t.n_max_evals - self.pop_size) / self.n_offsprings
        elif isinstance(t, MaximumGenerationTermination) and t.n_max_gen is not None:
            mg = t.n_max_gen - 1
        else:
            mg = 100
        self.period = max(1, int(round(self.fr * mg)))

    def _initialize_advance(self, infills=None, **kwargs):
        self.arc = infills                                        # Arc <- P

    def _infill(self):
        merged = Population.merge(self.arc, self.pop)             # Arc <- Update Archive(Arc, P)
        self.arc = merged[update_archive(merged.get("F"), self.pop_size)]
        pool = Population.merge(self.pop, self.arc)               # Q <- Reproduction(P u Arc, N)
        return self.mating.do(self.problem, pool, self.n_offsprings, algorithm=self, random_state=self.random_state)

    def _advance(self, infills=None, **kwargs):
        self.gen += 1
        R = Population.merge(self.pop, infills)                   # Pu <- P u Q
        F = R.get("F")
        N = self.pop_size
        fronts = NonDominatedSorting().do(F)
        keep = []
        for l, front in enumerate(fronts):
            keep.extend(front)
            if len(keep) >= N:
                break
        Fu = np.array(keep)
        if len(Fu) == N:
            self.pop = R[Fu]
            return
        Fl = np.asarray(fronts[l])
        head = Fu[:len(Fu) - len(Fl)]
        k = N - len(head)
        # normalisation b_N = (b - b_min) / s: b_min over Fu every generation, s = b_max - b_min over Fu kept fixed for
        # fr * MaxG generations. A zero range (an objective collapsed to one value) is replaced by S_ZERO, a tiny scale
        # as in the authors' PlatEMO code: any later spread in that objective then dominates the normalised space and
        # its archive extreme tilts the hyperplane back, so the objective can recover (with a scale of 1 it cannot,
        # e.g. DTLZ4 loses part of the front in about half of the runs)
        bmin = F[Fu].min(axis=0)
        if self.scale is None or self.gen >= self.next_refresh:
            s = F[Fu].max(axis=0) - bmin
            self.scale = np.where(s > 0, s, S_ZERO)
            self.next_refresh = self.gen + self.period
        FlN = (F[Fl] - bmin) / self.scale
        ArcN = (self.arc.get("F") - bmin) / self.scale
        A, D = hyperplane(ArcN[extreme_points(ArcN)], positive=self.positive_plane)     # Algorithm 2
        labels = ward_clusters(map_to_hyperplane(FlN, A, D), k)                        # Algorithm 1, line 11
        sel = nrv_select(FlN, A, D, labels, k)                                         # Algorithm 3
        self.pop = R[np.concatenate([head, Fl[sel]])]

    def _set_optimum(self):
        if self.output == "archive" and self.arc is not None:    # diagnostic only; the paper outputs P
            m = Population.merge(self.arc, self.pop)
            self.opt = m[update_archive(m.get("F"), self.pop_size)]
        else:
            super()._set_optimum()


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs):
    """NRV-MOEA needs no predefined reference directions (its reference vectors are the adaptive normal vectors through
    the cluster centres); ref_dirs is unused."""
    return NRVMOEA(pop_size=pop_size, sampling=sampling, crossover=crossover, mutation=mutation, repair=repair)
