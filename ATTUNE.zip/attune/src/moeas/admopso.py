"""ADMOPSO (adaptive distance-based multi-objective particle swarm optimisation algorithm with simple position update),
implemented from

    L. Wang, L. Hong, H. Fu, Z. Cai, Y. Zhong, L. Wang. Adaptive distance-based multi-objective particle swarm
    optimization algorithm with simple position update. Swarm and Evolutionary Computation 94:101890, 2025.
    doi:10.1016/j.swevo.2025.101890

Algorithm 3 of the paper. Initial positions from `sampling`, initial velocities random (line 2). One iteration: sort
the swarm by non-dominated front and crowding distance and draw L = 10 elite particles with the interval roulette of
Algorithm 2 (ProInt over 10 intervals, ProPar by Eq. 8); for every particle, the exemplar is the winner of the adaptive
PBI distance competition between two elites (Algorithm 1, Eqs. 4-7, reference point z* = origin, weight vector towards
the particle); velocity by Eq. 11 with omega decreasing linearly from 0.9 to 0.4; position by the simple position
probabilistic update of Eq. 9 with learning rate lr = 0.2 (Table 3); the N new particles are evaluated and the
environmental selection of CMOPSO (Algorithm 4: non-dominated sorting, SPEA2 truncation of the last front on objectives
normalised by the first front, as in PlatEMO's CMOPSO) keeps N of the 2N. No external archive and no mutation
(polynomial mutation belongs to the separate variant ADMOPSO-Poly of Section 4.7). Returns the non-dominated particles
of the final swarm.
"""
import numpy as np

from pymoo.core.algorithm import Algorithm
from pymoo.core.population import Population
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.util.display.multi import MultiObjectiveOutput
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting

# Section 3.1, values of the 10 interval probabilities taken from Xue, Cai, Neri (ref. [43])
PRO_INT = np.array([0.5602, 0.1505, 0.0846, 0.0568, 0.0415, 0.0318, 0.0250, 0.0201, 0.0163, 0.0132])


# ---------------------------------------------------------------------------------------------------------------------
# components (module-level so that they can be tested separately)
# ---------------------------------------------------------------------------------------------------------------------

def front_numbers(F):
    fronts = NonDominatedSorting().do(F)
    rank = np.empty(len(F), dtype=int)
    for k, fr in enumerate(fronts):
        rank[fr] = k
    return rank


def crowding_by_front(F, rank):
    """NSGA-II crowding distance computed within each front (as PlatEMO's CrowdingDistance(PopObj, FrontNo)):
    boundary points inf, objectives normalised by the front's range."""
    cd = np.zeros(len(F))
    for k in np.unique(rank):
        idx = np.flatnonzero(rank == k)
        if len(idx) <= 2:
            cd[idx] = np.inf
            continue
        Fk = F[idx]
        fmin, fmax = Fk.min(axis=0), Fk.max(axis=0)
        for j in range(F.shape[1]):
            order = np.argsort(Fk[:, j], kind="stable")
            cd[idx[order[0]]] = cd[idx[order[-1]]] = np.inf
            rng = fmax[j] - fmin[j]
            if rng > 0:
                f = Fk[order, j]
                cd[idx[order[1:-1]]] += (f[2:] - f[:-2]) / rng
    return cd


def sort_swarm(F):
    """Line 5 of Algorithm 3: ascending front number, then descending crowding distance (ties by index)."""
    rank = front_numbers(F)
    cd = crowding_by_front(F, rank)
    return np.lexsort((np.arange(len(F)), -cd, rank))


def pro_par(size):
    """Eq. 8: ProPar_i = (1 - i/interval) / sum_{i=1}^{interval} (1 - i/interval), i = 1..interval (rank in the
    interval); the last particle of an interval gets probability 0."""
    w = 1.0 - np.arange(1, size + 1) / size
    s = w.sum()
    return w / s if s > 0 else np.full(size, 1.0 / size)


def generate_elites(order, L, random_state, pro_int=PRO_INT):
    """Algorithm 2: the sorted swarm is divided into len(pro_int) consecutive intervals; L times, an interval is chosen
    by roulette on ProInt and a particle in it by roulette on ProPar (Eq. 8); the elites are the union (a set) of the
    chosen particles. Returns sorted indices into the swarm."""
    chunks = [c for c in np.array_split(order, len(pro_int)) if len(c)]
    p_int = pro_int[:len(chunks)] / pro_int[:len(chunks)].sum()
    elites = set()
    for _ in range(L):
        k = random_state.choice(len(chunks), p=p_int)
        c = chunks[k]
        elites.add(int(c[random_state.choice(len(c), p=pro_par(len(c)))]))
    return np.array(sorted(elites))


def pbi_distances(F_cand, F_i, z):
    """Eqs. 4-5 with the weight vector lambda pointing from the reference point z to the particle P_i:
    d1 = |(F - z)^T lambda| / ||lambda||, d2 = ||F - (z + d1 lambda / ||lambda||)||."""
    lam = F_i - z
    nl = np.linalg.norm(lam)
    D = np.atleast_2d(F_cand) - z
    if nl == 0:                                       # P_i at z: no direction, d2 = 0 and d1 the distance to z
        return np.linalg.norm(D, axis=1), np.zeros(len(D))
    u = lam / nl
    d1 = np.abs(D @ u)
    d2 = np.linalg.norm(D - d1[:, None] * u[None, :], axis=1)
    return d1, d2


def apd_value(d1, d2, wd):
    """Eq. 6: d = (1 - wd) d1 - wd d2; the competitor with the smaller d wins (Algorithm 1)."""
    return (1.0 - wd) * d1 - wd * d2


def apd_select(F, elites, wd, z, random_state):
    """Algorithm 1 for every particle i: two elites a, b drawn at random (distinct if possible, as CMOPSO's randperm);
    winner a if d(P_i, P_a) < d(P_i, P_b), else b. Returns the index of each particle's exemplar."""
    n, k = len(F), len(elites)
    if k == 1:
        return np.full(n, elites[0])
    ia = random_state.integers(0, k, size=n)
    ib = (ia + random_state.integers(1, k, size=n)) % k
    a, b = elites[ia], elites[ib]
    win = np.empty(n, dtype=int)
    for i in range(n):
        d1, d2 = pbi_distances(F[[a[i], b[i]]], F[i], z)
        d = apd_value(d1, d2, wd)
        win[i] = a[i] if d[0] < d[1] else b[i]
    return win


def spp_update(X, V, Xbest, omega, lr, xl, xu, random_state, r_per="variable"):
    """Eq. 11, V' = omega V + r (Xbest - X), with r ~ U[0, 1] drawn per variable as in CMOPSO, whose velocity update
    Eq. 11 rewrites (PlatEMO's CMOPSO: r2 = rand(1, D)); r_per="particle" draws one r per particle. Eq. 9,
    X' = X + V' (x) H(lr - eps), with eps ~ U[0, 1] per variable (H the Heaviside step, (x) element-wise). Positions are
    clipped to the box (as PlatEMO's evaluation does); the velocity V' is kept unmasked and unclipped."""
    n, d = X.shape
    r = random_state.random((n, d)) if r_per == "variable" else np.repeat(random_state.random(n)[:, None], d, axis=1)
    Vn = omega * V + r * (Xbest - X)
    H = (lr - random_state.random((n, d))) > 0
    Xn = np.clip(X + Vn * H, xl, xu)
    return Xn, Vn


def truncation(F, K):
    """SPEA2 truncation as in PlatEMO's CMOPSO: K times, delete the solution whose sorted distances to the remaining
    solutions are lexicographically smallest. Returns a boolean deletion mask."""
    n = len(F)
    with np.errstate(over="ignore"):          # normalised values can be huge if the first front is nearly flat
        D = np.sqrt(((F[:, None, :] - F[None, :, :]) ** 2).sum(axis=2))
    np.fill_diagonal(D, np.inf)
    alive = np.arange(n)
    for _ in range(K):
        T = np.sort(D[np.ix_(alive, alive)], axis=1)
        cand = np.arange(len(alive))
        for col in range(T.shape[1]):
            v = T[cand, col]
            cand = cand[v == v.min()]
            if len(cand) == 1:
                break
        alive = np.delete(alive, cand[0])
    dele = np.ones(n, dtype=bool)
    dele[alive] = False
    return dele


def environmental_selection(F, N, normalise=True):
    """Algorithm 4: fronts in order until the front that overflows, which is truncated by truncation(). As in CMOPSO's
    environmental selection (PlatEMO), which Algorithm 4 says it is the same as, the truncation distances are computed
    on objectives normalised by the minimum and maximum of the first front (an objective with zero range is left
    unscaled)."""
    rank = front_numbers(F)
    counts = np.cumsum(np.bincount(rank))
    last = int(np.searchsorted(counts, N))          # first front whose cumulative count reaches N
    nxt = rank < last
    L = np.flatnonzero(rank == last)
    if normalise:
        fmin, fmax = F[rank == 0].min(axis=0), F[rank == 0].max(axis=0)
        rngf = np.where(fmax > fmin, fmax - fmin, 1.0)
        F = (F - fmin) / rngf
    dele = truncation(F[L], len(L) - (N - nxt.sum()))
    nxt[L[~dele]] = True
    return np.flatnonzero(nxt)


# ---------------------------------------------------------------------------------------------------------------------
# algorithm
# ---------------------------------------------------------------------------------------------------------------------

class ADMOPSO(Algorithm):
    def __init__(self, pop_size=100, sampling=FloatRandomSampling(), L=10, lr=0.2, w_max=0.9, w_min=0.4,
                 ref_point="origin", init_velocity="random", r_per="variable",
                 normalise_truncation=True, output=MultiObjectiveOutput(), **kwargs):
        super().__init__(output=output, **kwargs)
        self.pop_size, self.sampling, self.L, self.lr = pop_size, sampling, L, lr
        self.w_max, self.w_min, self.ref_point, self.init_velocity = w_max, w_min, ref_point, init_velocity
        self.r_per, self.normalise_truncation = r_per, normalise_truncation

    def _setup(self, problem, **kwargs):
        assert not problem.has_constraints(), "ADMOPSO here is for unconstrained problems"
        self.xl, self.xu = np.asarray(problem.xl, float), np.asarray(problem.xu, float)

    def _initialize_infill(self):
        return self.sampling.do(self.problem, self.pop_size, random_state=self.random_state)

    def _initialize_advance(self, infills=None, **kwargs):
        X = infills.get("X").astype(float)
        if self.init_velocity == "random":            # Algorithm 3, line 2; V ~ U[xl - x, xu - x] (x + v in the box)
            V = self.random_state.uniform(self.xl - X, self.xu - X)
        else:
            V = np.zeros_like(X)
        infills.set("V", V)
        self.pop = infills

    def progress(self):
        """iter / maxiters of Eq. 7 as the share of the budget used so far (FE / maxFE, termination progress)."""
        p = float(getattr(self.termination, "perc", 0.0) or 0.0)
        return min(max(p, 0.0), 1.0)

    def _infill(self):
        rs = self.random_state
        X, V, F = self.pop.get("X").astype(float), self.pop.get("V"), self.pop.get("F")
        order = sort_swarm(F)                                                   # line 5
        elites = generate_elites(order, self.L, rs)                             # line 6, Algorithm 2
        t = self.progress()
        wd = t                                                                  # line 7, Eq. 7
        omega = self.w_max - (self.w_max - self.w_min) * t                      # Section 3.2: 0.9 -> 0.4 linearly
        # Section 3.1: z* is the origin ("lambda is the weight vector of the current particle P_i to the origin");
        # ref_point="ideal" (the swarm's minimum per objective) is a sensitivity variant only
        z = F.min(axis=0) if self.ref_point == "ideal" else np.zeros(F.shape[1])
        win = apd_select(F, elites, wd, z, rs)                                  # line 9, Algorithm 1
        Xn, Vn = spp_update(X, V, X[win], omega, self.lr, self.xl, self.xu, rs, self.r_per)  # lines 10-11, Eqs. 11, 9
        return Population.new(X=Xn, V=Vn)

    def _advance(self, infills=None, **kwargs):
        assert len(infills) == self.pop_size
        merged = Population.merge(self.pop, infills)
        keep = environmental_selection(merged.get("F"), self.pop_size, self.normalise_truncation)  # line 13, Alg. 4
        self.pop = merged[keep]


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs):
    """ADMOPSO with the paper's parameters (L = 10, lr = 0.2; Table 3). It has no crossover and no mutation, so the
    supplied SBX/PM are not used; ref_dirs is not used (the PBI weight vector is the direction of each particle). The
    rule repair is not applied to positions (it rounds and re-orders genes, which would break the velocity dynamics);
    the problem rounds and repairs each position when it is evaluated."""
    return ADMOPSO(pop_size=pop_size, sampling=sampling)
