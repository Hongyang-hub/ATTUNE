"""MaOEA-HAP, implemented from

    X. Yue, W. Wen, Y. Jiang, Y. Tian, H. Peng. A hyper-curvature balanced indicator and adaptive phase exploration
    co-driven evolutionary algorithm for many-objective optimization. Swarm and Evolutionary Computation 102:102313,
    2026. doi:10.1016/j.swevo.2026.102313

Algorithm 1. Two sets of at most N solutions: an elite archive kept by the I_eps+ fitness exactly as Two_Arch2's
convergence archive (Section 3.2, Eq. (2)-(3), Algorithm 2), and the population P. Mating (Section 3.1): N/2 parents
from the elite archive by a dominance-based binary tournament and N/2 drawn at random from P; SBX between an elite and a
population parent (two children per pair) and polynomial mutation of every child give N offspring.
Elite <- UpdateElite(Elite + offspring); P <- environmental selection (Algorithm 3) of P + offspring:
  * F1 = the solutions that are not ADP-dominated (Section 3.4, Algorithm 4): Pareto-dominated solutions are
    ADP-dominated (condition (1)); a Pareto non-dominated solution is ADP-dominated when its nearest solution in angle
    (its adaptive niche) is mutually non-dominated with it and has a larger ADP value, Eq. (13)
    ADP(x) = sum_{k=1}^{m} theta_k / k (condition (2));
  * if |F1| < N, P = F1; otherwise, on objectives normalised over F1, m boundary solutions are taken first and the rest
    are added one at a time by the largest hyper-curvature balanced fitness, Eq. (12) = D_HCBM / C_HCBM (minimum angle
    to the selected solutions over the distance to the estimated L_lp surface, Eq. (7)-(8), p = 1/m), when the phase
    factor k = 0, or by the largest minimum angle when k = 1.
The phase factor is updated after every generation (Algorithm 5): k = 1 if C_HCBM < D = 1 for every member of P, else
k = 0. The output is P.
"""
import math

import numpy as np

from pymoo.core.algorithm import Algorithm
from pymoo.core.initialization import Initialization
from pymoo.core.population import Population
from pymoo.core.repair import NoRepair
from pymoo.util.display.multi import MultiObjectiveOutput

try:
    from moeas._twoarch_common import eps_truncate, nondominated_mask, dominates, dominance_tournament, normalize
except ImportError:                                     # imported as a top-level module
    from _twoarch_common import eps_truncate, nondominated_mask, dominates, dominance_tournament, normalize

LP_GRID = np.round(np.arange(0.5, 2.0 + 1e-9, 0.1), 10)   # Section 3.3: candidate curvatures 0.5 ... 2.0 (step 0.1)
D_PHASE = 1.0                                             # Section 3.5: threshold D = 1
ASF_EPS = 1e-6                                            # weight of the other axes in the boundary-solution ASF
TINY = 1e-12


def angle_matrix(Fn):
    """Eq. (11): the angle between the objective vectors of every pair of solutions (a zero vector is orthogonal to
    everything)."""
    nrm = np.linalg.norm(Fn, axis=1)
    U = Fn / np.maximum(nrm, TINY)[:, None]
    return np.arccos(np.clip(U @ U.T, -1.0, 1.0))


def adp_values(A, m):
    """Eq. (13): ADP(x) = sum_{k=1}^{m} theta_k / k, theta_k = angle to the k-th nearest other solution (larger = less
    crowded). A is the angle matrix with +inf on the diagonal; with fewer than m other solutions the available ones
    are used."""
    kk = min(m, len(A) - 1)
    if kk <= 0:
        return np.zeros(len(A))
    th = np.sort(A, axis=1)[:, :kk]
    return (th / np.arange(1, kk + 1)[None, :]).sum(axis=1)


def adp_front(F):
    """Algorithm 4 (NondominateSort_ADP) on the merged population F; returns the indices of F1.

    Angles (Eq. (11)) and ADP values (Eq. (13)) are computed over the whole population on objectives normalised by its
    ideal and nadir point (Eq. (4)-(6)). x ADP-dominates y if (1) x Pareto-dominates y, or (2) x and y are mutually
    non-dominated, x is y's nearest solution in angle (the adaptive niche of y) and ADP(x) > ADP(y). F1 holds the
    solutions that no solution ADP-dominates. This reading reproduces the worked example of Fig. 4 (X2 and X5 pruned,
    X1, X3, X4, X6 kept). If every Pareto non-dominated solution were pruned (not observed), F1 is the Pareto front."""
    F = np.asarray(F, float)
    n, m = F.shape
    nd = nondominated_mask(F)
    if n <= 1:
        return np.flatnonzero(nd)
    A = angle_matrix(normalize(F))
    np.fill_diagonal(A, np.inf)
    adp = adp_values(A, m)
    nn = np.argmin(A, axis=1)                                   # nearest solution (first index on ties)
    mutual = ~dominates(F[nn], F) & ~dominates(F, F[nn])
    pruned = mutual & (adp[nn] > adp)
    keep = nd & ~pruned
    if not keep.any():
        keep = nd
    return np.flatnonzero(keep)


def estimate_lp(Fn):
    """Section 3.3: the curvature lp in {0.5, 0.6, ..., 2.0} that minimises the spread of the normalised lp-distances
    ||f'(x)||_lp of the non-dominated solutions Fn (objectives normalised by the set's ideal and nadir point).
    'Normalised distances' are read as in the authors' PlatEMO code (Shape_Estimate.m): d / max(d) after discarding
    distances above Q3 + 1.5 IQR; the spread is the standard deviation (same minimiser as the variance)."""
    Fn = np.asarray(Fn, float)
    n = len(Fn)
    best, best_v = LP_GRID[0], np.inf
    for lp in LP_GRID:
        d = (np.abs(Fn) ** lp).sum(axis=1) ** (1.0 / lp)
        s = np.sort(d)
        q1, q3 = s[max(int(n * 0.25), 1) - 1], s[max(int(n * 0.75), 1) - 1]
        d = d[d <= q3 + 1.5 * (q3 - q1)]
        if len(d) < 2 or d.max() <= 0:
            continue
        v = np.std(d / d.max(), ddof=1)
        if v < best_v:                                          # first minimum (MATLAB min)
            best, best_v = lp, v
    return best


def c_hcbm(Fn, lp, p):
    """Eq. (7)-(8): D(x) = f'(x) / ||f'(x)||_lp is the projection onto the surface sum |y_i|^lp = 1 and
    C_HCBM(x) = (sum_i |f'_i(x) - D_i(x)|^p)^(1/p) with the spatial factor p = 1/m."""
    nrm = (np.abs(Fn) ** lp).sum(axis=1) ** (1.0 / lp)
    Dp = Fn / np.maximum(nrm, TINY)[:, None]
    return (np.abs(Fn - Dp) ** p).sum(axis=1) ** (1.0 / p)


def boundary_solutions(Fn):
    """Algorithm 3 line 8: m boundary solutions. For axis j the solution minimising the achievement scalarising
    function max_i f'_i / w_i with w = e_j (other weights 1e-6), i.e. the solution closest to the j-th axis (NSGA-III's
    extreme points; PlatEMO's MaOEA-HAP uses the same weights). Each axis gets a different solution where possible."""
    n, m = Fn.shape
    chosen = []
    for j in range(m):
        w = np.full(m, ASF_EPS)
        w[j] = 1.0
        asf = (Fn / w).max(axis=1)
        if len(chosen) < n:
            asf[chosen] = np.inf
        chosen.append(int(np.argmin(asf)))
    return list(dict.fromkeys(chosen))


def hcbm_select(Fn, N, k, p):
    """Algorithm 3 lines 8-29 on the normalised objectives Fn of F1 (|F1| >= N). Returns a boolean mask of S."""
    n = len(Fn)
    S = boundary_solutions(Fn)[:N]                              # line 8
    inS = np.zeros(n, bool)
    inS[S] = True
    if inS.sum() >= N:
        return inS
    A = angle_matrix(Fn)                                        # line 11
    min_ang = A[:, inS].min(axis=1)                             # lines 15 / 23: minimum angle to S (AOS_min)
    if k == 0:
        C = c_hcbm(Fn, estimate_lp(Fn), p)                      # line 13, Eq. (8); lp from the current front F1
        inv_c = 1.0 / np.maximum(C, TINY)
    while inS.sum() < N:                                        # line 10
        score = inv_c * min_ang if k == 0 else min_ang          # Eq. (12) (lines 17-18) / line 25
        i = int(np.argmax(np.where(inS, -np.inf, score)))
        inS[i] = True
        min_ang = np.minimum(min_ang, A[:, i])
    return inS


def environmental_selection(F, N, k, p):
    """Algorithm 3 on the merged objectives F. Returns the indices of F kept as the next population."""
    F1 = adp_front(F)                                           # line 2
    if len(F1) < N:                                             # lines 3-6
        return F1
    return F1[hcbm_select(normalize(F[F1]), N, k, p)]          # line 7 (normalisation of F1), lines 8-29


def phase_factor(F, p):
    """Algorithm 5: k = 1 if C_HCBM (Eq. (8)) < D = 1 for every member of the population, otherwise k = 0. Objectives
    are normalised by the population's ideal and nadir point and lp is estimated on its non-dominated solutions."""
    F = np.asarray(F, float)
    if len(F) < 2:
        return 0
    Fn = normalize(F)
    lp = estimate_lp(Fn[nondominated_mask(F)])
    return int(np.all(c_hcbm(Fn, lp, p) < D_PHASE))


class MaOEAHAP(Algorithm):

    def __init__(self, pop_size=100, sampling=None, crossover=None, mutation=None, repair=None, p=None,
                 output=MultiObjectiveOutput(), **kwargs):
        super().__init__(output=output, **kwargs)
        self.pop_size = pop_size
        self.p = p                                               # Section 3.3: spatial factor p = 1/m
        self.crossover, self.mutation = crossover, mutation
        self.repair = repair if repair is not None else NoRepair()
        self.initialization = Initialization(sampling, repair=self.repair)
        self.elite = None
        self.k = 0                                               # phase factor (Algorithm 1 starts with k = 0)
        self.k_history = []

    def _setup(self, problem, **kwargs):
        if self.p is None:
            self.p = 1.0 / problem.n_obj

    def _initialize_infill(self):
        return self.initialization.do(self.problem, self.pop_size, algorithm=self, random_state=self.random_state)

    def _update_elite(self, new):
        E = new if self.elite is None else Population.merge(self.elite, new)
        self.elite = E[eps_truncate(E.get("F"), self.pop_size)]

    def _initialize_advance(self, infills=None, **kwargs):
        self._update_elite(infills)                              # Algorithm 1 line 3
        self.pop = infills[environmental_selection(infills.get("F"), self.pop_size, self.k, self.p)]   # line 4

    def _infill(self):
        rng, N = self.random_state, self.pop_size
        n_pairs = math.ceil(N / 2)
        a = dominance_tournament(self.elite.get("F"), n_pairs, rng)    # N/2 from the elite archive
        b = rng.integers(0, len(self.pop), n_pairs)                     # N/2 at random from P
        both = Population.merge(self.elite, self.pop)
        parents = np.column_stack([a, len(self.elite) + b])
        off = self.crossover(self.problem, both, parents=parents, random_state=rng)   # SBX, two children per pair
        off = Population.new(X=off.get("X")[:N])
        off = self.mutation(self.problem, off, random_state=rng)       # PM on every child
        off = Population.new(X=off.get("X"))
        off = self.repair(self.problem, off, random_state=rng)
        assert len(off) == N
        return off

    def _advance(self, infills=None, **kwargs):
        self._update_elite(infills)                                     # line 8
        R = Population.merge(self.pop, infills)
        self.pop = R[environmental_selection(R.get("F"), self.pop_size, self.k, self.p)]   # line 9
        self.k = phase_factor(self.pop.get("F"), self.p)                # line 10
        self.k_history.append(self.k)

    def _set_optimum(self):
        self.opt = self.pop                                             # Algorithm 1 returns P


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs):
    """MaOEA-HAP with |Elite| <= pop_size, |P| <= pop_size and p = 1/m; ref_dirs are not used (the algorithm needs no
    reference vectors)."""
    return MaOEAHAP(pop_size=pop_size, sampling=sampling, crossover=crossover, mutation=mutation, repair=repair)
