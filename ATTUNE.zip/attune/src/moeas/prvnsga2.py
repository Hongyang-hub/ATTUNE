"""PRV-NSGA-II: NSGA-II with the Pareto dominance relation based on reference vectors (PRV-dominance).

Wang S., Wang H., Wei Z., Wang F., Zhu Q., Zhao J., Cui Z. A Pareto dominance relation based on reference vectors for
evolutionary many-objective optimization. Applied Soft Computing 157 (2024) 111505. doi:10.1016/j.asoc.2024.111505

Environmental selection (Algorithm 2, lines 4-16) on R_t = P_t u Q_t:
  1. normalise R_t with the minimum and maximum of every objective in R_t (Eq. 2);
  2. associate every solution with its closest reference vector (Algorithm 1); the distance between a normalised point
     and a reference vector is the perpendicular (Euclidean) distance to the vector's line, as in the authors' code;
     Density = number of solutions of R_t associated with a vector (Section 3.2);
  3. Rank(x) = sum over the objectives of the position of x in R_t sorted by f_j (Eq. 3; 1 = smallest). Equal values are
     ordered lexicographically by the whole objective vector and then by position in R_t (parents first), so exact
     copies get different ranks (as in the authors' code, whose positions come from a stable sort) and a Pareto-dominating
     solution always has the smaller Rank (which keeps PRV-dominance acyclic);
  4. non-PRV-dominated sorting of R_t (repeatedly peel the solutions that no remaining solution PRV-dominates); whole
     fronts while they fit;
  5. the remaining places go to the solutions of the last front with the smallest distance to their reference vector
     (ties at random).
x PRV-dominates y iff x Pareto-dominates y, or x and y are Pareto-equivalent and
  (1) same subregion and Rank(x) < Rank(y), or
  (2) different subregions, Rank(x) < Rank(y), Density(y) > Density(x) > 1, and the subregion of x is in the
      neighbourhood of that of y or vice versa. Neighbourhood of a reference vector: its max(2, ceil(N * xi)) closest
      reference vectors, itself included (the authors' code; N * xi = 1 for N = 100, xi = 1 %, would otherwise contain
      only the vector itself), xi = 1 % (Section 4.6).
Mating (Algorithm 2, line 2): binary tournament on (PRV front, Rank), a random one of the two on ties (the authors' code
uses PlatEMO's TournamentSelection(2, N, FrontNo, Rank)); SBX and polynomial mutation as passed in (Section 4.1).
N reference vectors, N = population size (Section 3.4): the `ref_dirs` passed to make().

`prv=False` switches PRV-dominance off: Pareto dominance, the last front truncated by NSGA-II's crowding distance and
NSGA-II's crowded binary tournament, i.e. pymoo's NSGA2 (used to check the shared code against pymoo, bit for bit).
"""
import numpy as np

from pymoo.algorithms.moo.nsga2 import NSGA2, binary_tournament
from pymoo.core.survival import Survival
from pymoo.operators.selection.tournament import TournamentSelection
from pymoo.operators.survival.rank_and_crowding.metrics import get_crowding_function
from pymoo.util.randomized_argsort import randomized_argsort

XI = 0.01   # neighbourhood ratio xi (Section 4.6: "xi = 1 % is used as a good choice in this paper")


def normalise(F):
    """Eq. (2): (f_i - z_min_i) / (z_max_i - z_min_i) over the given set; a constant objective maps to 0."""
    zmin, zmax = F.min(axis=0), F.max(axis=0)
    rng = zmax - zmin
    return (F - zmin) / np.where(rng > 0, rng, 1.0)


def associate(Fn, W):
    """Index of the closest reference vector (perpendicular distance to its line) and that distance, for every row."""
    Wu = W / np.linalg.norm(W, axis=1, keepdims=True)
    proj = Fn @ Wu.T                                            # length of the projection on each unit vector
    d = np.linalg.norm(Fn[:, None, :] - proj[:, :, None] * Wu[None, :, :], axis=2)   # ||f - (f.w) w||
    a = d.argmin(axis=1)
    return a, d[np.arange(len(Fn)), a]


def rank_sum(F):
    """Eq. (3): sum over the objectives of the 1-based position of x in the set sorted by f_j. Ties in f_j: ordered
    lexicographically by the whole objective vector, then by row index (copies: the earlier row first)."""
    n, m = F.shape
    lex = np.lexsort([np.arange(n)] + [F[:, a] for a in range(m - 1, -1, -1)])   # lexicographic order of the rows
    pos = np.empty(n, dtype=np.int64)
    pos[lex] = np.arange(n)
    R = np.zeros(n, dtype=np.int64)
    for j in range(m):
        order = np.lexsort((pos, F[:, j]))                     # by f_j, ties by the lexicographic position
        r = np.empty(n, dtype=np.int64)
        r[order] = np.arange(1, n + 1)
        R += r
    return R


def neighbourhood(W, xi=XI):
    """Boolean matrix B[a, b]: b is one of the max(2, ceil(N * xi)) closest reference vectors of a (a itself included)."""
    N = len(W)
    T = min(N, max(2, int(np.ceil(N * xi - 1e-9))))
    D = np.linalg.norm(W[:, None, :] - W[None, :, :], axis=2)
    np.fill_diagonal(D, -1.0)                                  # the vector itself comes first
    B = np.zeros((N, N), dtype=bool)
    nb = np.argsort(D, axis=1, kind="stable")[:, :T]
    B[np.arange(N)[:, None], nb] = True
    return B


def pareto_dominance_matrix(F):
    """P[x, y] = x Pareto-dominates y (minimisation)."""
    le = (F[:, None, :] <= F[None, :, :]).all(axis=2)
    lt = (F[:, None, :] < F[None, :, :]).any(axis=2)
    return le & lt


def prv_dominance_matrix(F, assoc, density, rank, B):
    """Dom[x, y] = x PRV-dominates y (Section 3.3)."""
    P = pareto_dominance_matrix(F)
    equiv = ~P & ~P.T
    same = assoc[:, None] == assoc[None, :]
    better = rank[:, None] < rank[None, :]
    dx, dy = density[assoc][:, None], density[assoc][None, :]
    nbr = B[assoc[:, None], assoc[None, :]] | B[assoc[None, :], assoc[:, None]]
    cond1 = same & better
    cond2 = ~same & better & (dy > dx) & (dx > 1) & nbr
    return P | (equiv & (cond1 | cond2))


def sort_by_relation(Dom, n_stop=None):
    """Fronts of an acyclic dominance relation: repeatedly take the remaining solutions no remaining one dominates."""
    n = len(Dom)
    remaining = np.ones(n, dtype=bool)
    cnt = Dom.sum(axis=0).astype(np.int64)                     # number of dominators of every solution
    fronts, ranked = [], 0
    while remaining.any():
        front = np.flatnonzero(remaining & (cnt == 0))
        if len(front) == 0:
            raise RuntimeError("dominance relation has a cycle")
        fronts.append(front)
        remaining[front] = False
        cnt -= Dom[front].sum(axis=0)
        ranked += len(front)
        if n_stop is not None and ranked >= n_stop:
            break
    return fronts


class PRVSurvival(Survival):
    def __init__(self, ref_dirs, xi=XI, prv=True):
        super().__init__(filter_infeasible=True)
        self.W = np.asarray(ref_dirs, dtype=float)
        self.B = neighbourhood(self.W, xi)
        self.prv = prv
        self.cd = None if prv else get_crowding_function("cd")

    def _do(self, problem, pop, *args, n_survive=None, random_state=None, **kwargs):
        F = pop.get("F").astype(float, copy=False)
        if self.prv:
            assoc, dist = associate(normalise(F), self.W)                       # Algorithm 2, line 5
            density = np.bincount(assoc, minlength=len(self.W))
            rank = rank_sum(F)                                                   # line 6
            Dom = prv_dominance_matrix(F, assoc, density, rank, self.B)
        else:
            Dom = pareto_dominance_matrix(F)
        fronts = sort_by_relation(Dom, n_stop=n_survive)                         # line 7
        survivors = []
        for k, front in enumerate(fronts):
            I = np.arange(len(front))  # noqa: E741
            if self.prv:
                if len(survivors) + len(front) > n_survive:                      # lines 13-16
                    need = n_survive - len(survivors)
                    I = np.lexsort((random_state.random(len(front)), dist[front]))[:need]  # noqa: E741
                for i in front:
                    pop[i].set("rank", k)
                    pop[i].set("prv_rank", rank[i])
                    pop[i].set("ref_dist", dist[i])
            else:                                                                # pymoo's RankAndCrowding, verbatim
                if len(survivors) + len(front) > n_survive:
                    n_remove = len(survivors) + len(front) - n_survive
                    c = self.cd.do(F[front, :], n_remove=n_remove)
                    I = randomized_argsort(c, order="descending", method="numpy", random_state=random_state)  # noqa: E741
                    I = I[:-n_remove]  # noqa: E741
                else:
                    c = self.cd.do(F[front, :], n_remove=0)
                for j, i in enumerate(front):
                    pop[i].set("rank", k)
                    pop[i].set("crowding", c[j])
            survivors.extend(front[I].tolist())
        return pop[survivors]


def prv_tournament(pop, P, random_state=None, **kwargs):
    """Binary tournament: lower PRV front wins, then lower Rank, then a random one of the two."""
    S = np.empty(len(P), dtype=int)
    for t, (a, b) in enumerate(P):
        ka = (pop[a].get("rank"), pop[a].get("prv_rank"))
        kb = (pop[b].get("rank"), pop[b].get("prv_rank"))
        S[t] = a if ka < kb else b if kb < ka else (a if random_state.random() < 0.5 else b)
    return S[:, None]


class PRVNSGA2(NSGA2):
    def __init__(self, ref_dirs, pop_size=100, xi=XI, prv=True, **kwargs):
        sel = TournamentSelection(func_comp=prv_tournament if prv else binary_tournament)
        super().__init__(pop_size=pop_size, selection=sel, survival=PRVSurvival(ref_dirs, xi, prv), **kwargs)
        self.ref_dirs, self.prv = ref_dirs, prv

    def _set_optimum(self, **kwargs):
        if not self.prv:
            return super()._set_optimum(**kwargs)
        # the result is the Pareto non-dominated part of the population (the first PRV front is only a subset of it)
        F = self.pop.get("F")
        self.opt = self.pop[~pareto_dominance_matrix(F).any(axis=0)]


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs, xi=XI, prv=True):
    """PRV-NSGA-II with the given reference vectors (the paper uses N uniform vectors, N = population size)."""
    return PRVNSGA2(ref_dirs=ref_dirs, pop_size=pop_size, xi=xi, prv=prv, sampling=sampling, crossover=crossover,
                    mutation=mutation, repair=repair, eliminate_duplicates=False)
