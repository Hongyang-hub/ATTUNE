"""SMPSO (Speed-constrained Multi-objective PSO), implemented from

    A.J. Nebro, J.J. Durillo, J. Garcia-Nieto, C.A. Coello Coello, F. Luna, E. Alba. SMPSO: A new PSO-based metaheuristic
    for multi-objective optimization. IEEE Symposium on Computational Intelligence in Multi-Criteria Decision-Making
    (MCDM 2009), 66-73. doi:10.1109/MCDM.2009.4938830

Algorithm 1 of the paper. One iteration: velocities by Eq. 2 multiplied by the constriction coefficient (Eqs. 3-4) and
bounded per variable by Eqs. 5-6; positions by Eq. 1 (a position leaving the box is set to the bound and that velocity
component is multiplied by 0.001, Section II-C); polynomial mutation (pm = 1/L, eta_m = 20) as turbulence on 15% of the
particles (Section II-C, Table I, Section IV-A); evaluation of all particles; update of the leaders archive (crowding
distance, size 100) and of the particle memories. The leader (global guide) is the one with the larger crowding distance
of two archive members drawn at random (Section II-B). C1, C2 ~ U[1.5, 2.5] (Section II-C), r1, r2 ~ U[0, 1] (Section
II-A); the inertia weight is not given in the paper and is w = 0.1 as in jMetal. Returns the leaders archive.
"""
import numpy as np

from pymoo.core.algorithm import Algorithm
from pymoo.core.population import Population
from pymoo.operators.mutation.pm import mut_pm
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.util.display.multi import MultiObjectiveOutput


# ---------------------------------------------------------------------------------------------------------------------
# components (module-level so that they can be tested separately)
# ---------------------------------------------------------------------------------------------------------------------

def constriction(c1, c2):
    """Eqs. 3-4 as printed and as in jMetal: phi = C1 + C2; chi = 2 / (2 - phi - sqrt(phi^2 - 4 phi)) if phi > 4,
    else 1 (Eq. 4 gives phi = 1 for C1 + C2 <= 4, for which Eq. 3 is complex; jMetal returns 1). Note that chi < 0 for
    phi > 4 because Eq. 3 has no absolute value (Clerc and Kennedy's coefficient has one)."""
    phi = np.asarray(c1, float) + np.asarray(c2, float)
    with np.errstate(invalid="ignore"):
        chi = 2.0 / (2.0 - phi - np.sqrt(np.maximum(phi * phi - 4.0 * phi, 0.0)))
    return np.where(phi > 4.0, chi, 1.0)


def bound_velocity(V, delta):
    """Eqs. 5-6: v > delta -> delta; v <= -delta -> -delta, with delta_j = (upper_j - lower_j) / 2."""
    return np.where(V > delta, delta, np.where(V <= -delta, -delta, V))


def update_position(X, V, xl, xu, change_velocity=0.001):
    """Eq. 1 and the bound handling of Section II-C: a variable that leaves [xl, xu] is set to the violated bound and
    its velocity component is multiplied by change_velocity (0.001 in SMPSO; -1 would be OMOPSO's reversal)."""
    Xn = X + V
    Vn = V.copy()
    lo, hi = Xn < xl, Xn > xu
    Xn = np.where(lo, xl, np.where(hi, xu, Xn))
    Vn[lo | hi] *= change_velocity
    return Xn, Vn


def crowding_distance(F):
    """NSGA-II crowding distance of the rows of F: boundary points of each objective get inf, interior points the sum of
    (f[i+1] - f[i-1]) / (f_max - f_min); objectives with zero range contribute nothing."""
    n, m = F.shape
    if n <= 2:
        return np.full(n, np.inf)
    cd = np.zeros(n)
    for j in range(m):
        order = np.argsort(F[:, j], kind="stable")
        f = F[order, j]
        rng = f[-1] - f[0]
        if rng <= 0:
            continue
        cd[order[0]] = cd[order[-1]] = np.inf
        cd[order[1:-1]] += (f[2:] - f[:-2]) / rng
    return cd


def dominates(a, B):
    """Boolean vector: a dominates B[k] (minimisation)."""
    return np.all(a <= B, axis=1) & np.any(a < B, axis=1)


def dominated_by_any(a, B):
    return bool(np.any(np.all(B <= a, axis=1) & np.any(B < a, axis=1)))


class CrowdingArchive:
    """Bounded archive of non-dominated solutions (jMetal's CrowdingArchive): a solution is rejected if an archive
    member dominates it or has the same objective vector; members it dominates are removed; if the archive then exceeds
    max_size, the member with the smallest crowding distance (computed on the archive) is removed (first on ties)."""

    def __init__(self, max_size):
        self.max_size = max_size
        self.F = None
        self.items = []

    def __len__(self):
        return len(self.items)

    def add(self, f, item):
        f = np.asarray(f, float)
        if self.F is None or len(self.items) == 0:
            self.F, self.items = f[None].copy(), [item]
            return True
        if dominated_by_any(f, self.F) or np.any(np.all(self.F == f, axis=1)):
            return False
        keep = ~dominates(f, self.F)
        self.F = np.vstack([self.F[keep], f[None]])
        self.items = [it for it, k in zip(self.items, keep) if k] + [item]
        if len(self.items) > self.max_size:
            worst = int(np.argmin(crowding_distance(self.F)))
            self.F = np.delete(self.F, worst, axis=0)
            del self.items[worst]
        return True


def select_leaders(cd, n, random_state):
    """Section II-B: for each of n particles, two archive members drawn at random (distinct when the archive has at
    least two members); the one with the larger crowding distance is the leader (the first drawn on ties)."""
    k = len(cd)
    if k == 1:
        return np.zeros(n, dtype=int)
    a = random_state.integers(0, k, size=n)
    b = (a + random_state.integers(1, k, size=n)) % k          # uniform over the other k - 1 members
    return np.where(cd[b] > cd[a], b, a)


def pbest_replace(F_new, F_pbest):
    """Particle memory update (jMetal: replace unless the memory dominates the new position)."""
    return ~(np.all(F_pbest <= F_new, axis=1) & np.any(F_pbest < F_new, axis=1))


# ---------------------------------------------------------------------------------------------------------------------
# algorithm
# ---------------------------------------------------------------------------------------------------------------------

class SMPSO(Algorithm):
    def __init__(self, pop_size=100, archive_size=100, sampling=FloatRandomSampling(), c_min=1.5, c_max=2.5,
                 w=0.1, change_velocity=0.001, mutation_frac=0.15, eta_m=20.0, prob_var=None, mutated=None,
                 output=MultiObjectiveOutput(), **kwargs):
        super().__init__(output=output, **kwargs)
        self.pop_size, self.archive_size, self.sampling = pop_size, archive_size, sampling
        self.c_min, self.c_max, self.w, self.change_velocity = c_min, c_max, w, change_velocity
        self.mutation_frac, self.eta_m, self.prob_var = mutation_frac, eta_m, prob_var
        self.mutated_given = mutated            # explicit indices of the mutated particles (validation only)

    def _setup(self, problem, **kwargs):
        assert not problem.has_constraints(), "SMPSO here is for unconstrained problems"
        self.xl, self.xu = np.asarray(problem.xl, float), np.asarray(problem.xu, float)
        self.delta = (self.xu - self.xl) / 2.0                                          # Eq. 6
        # turbulence on a fixed 15% of the swarm (Section II-C); jMetal uses particles i % 6 == 0
        self.mutated = np.arange(int(round(self.mutation_frac * self.pop_size))) if self.mutated_given is None \
            else np.asarray(self.mutated_given, dtype=int)
        self.pm_prob = self.prob_var if self.prob_var is not None else 1.0 / problem.n_var  # Table I: pm = 1/L

    def _initialize_infill(self):
        return self.sampling.do(self.problem, self.pop_size, random_state=self.random_state)

    def _initialize_advance(self, infills=None, **kwargs):
        self.pop = infills
        X, F = infills.get("X").astype(float), infills.get("F")
        self.V = np.zeros_like(X)                                       # initial velocity 0 (jMetal)
        self.PX, self.PF = X.copy(), F.copy()                           # particle memories (pbest)
        self.leaders_archive = CrowdingArchive(self.archive_size)
        for ind, f in zip(infills, F):                                  # Line 2: leaders from the initial swarm
            self.leaders_archive.add(f, ind)

    def _infill(self):
        rs, N = self.random_state, self.pop_size
        X = self.pop.get("X").astype(float)
        # Line 5: computeSpeed (Eqs. 2-6)
        leaders = select_leaders(crowding_distance(self.leaders_archive.F), N, rs)
        G = np.array([self.leaders_archive.items[k].X for k in leaders], dtype=float)
        r1, r2 = rs.random(N), rs.random(N)
        c1, c2 = rs.uniform(self.c_min, self.c_max, N), rs.uniform(self.c_min, self.c_max, N)
        chi = constriction(c1, c2)
        V = chi[:, None] * (self.w * self.V + (c1 * r1)[:, None] * (self.PX - X) + (c2 * r2)[:, None] * (G - X))
        V = bound_velocity(V, self.delta)
        # Line 6: updatePosition (Eq. 1, bound handling of Section II-C)
        Xn, self.V = update_position(X, V, self.xl, self.xu, self.change_velocity)
        # Line 7: turbulence, polynomial mutation of 15% of the particles
        if len(self.mutated):
            k = len(self.mutated)
            Xn[self.mutated] = mut_pm(Xn[self.mutated], self.xl, self.xu, np.full(k, self.eta_m),
                                      np.full(k, self.pm_prob), at_least_once=False, random_state=rs)
        return Population.new(X=Xn)

    def _advance(self, infills=None, **kwargs):
        assert len(infills) == self.pop_size
        F = infills.get("F")
        for ind, f in zip(infills, F):                                  # Line 9: updateLeadersArchive
            self.leaders_archive.add(f, ind)
        rep = pbest_replace(F, self.PF)                                 # Line 10: updateParticlesMemory
        X = infills.get("X").astype(float)
        self.PX[rep], self.PF[rep] = X[rep], F[rep]
        self.pop = infills

    def _set_optimum(self):
        self.opt = Population.create(*self.leaders_archive.items)              # Line 13: the leaders archive


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs):
    """SMPSO with the paper's parameters (swarm and archive 100). SBX is not part of SMPSO; the supplied PM is not used
    because SMPSO's turbulence is polynomial mutation with pm = 1/L and eta_m = 20 on 15% of the particles, applied
    here without the rounding repair attached to the supplied operator so that positions stay real-valued. The rule
    repair is not applied to positions (it rounds and re-orders genes, which would break the velocity dynamics); the
    problem rounds and repairs each position when it is evaluated. ref_dirs is not used."""
    return SMPSO(pop_size=pop_size, archive_size=100, sampling=sampling)
