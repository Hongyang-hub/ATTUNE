"""Two_Arch2, implemented from

    H. Wang, L. Jiao, X. Yao. Two_Arch2: An Improved Two-Archive Algorithm for Many-Objective Optimization.
    IEEE Transactions on Evolutionary Computation 19(4):524-541, 2015. doi:10.1109/TEVC.2014.2350987

Two archives of fixed size (Section III-A, IV-C): the convergence archive CA (|CA| = N) is updated with the I_eps+
fitness of IBEA (Eq. (1)-(2), Algorithm 2); the diversity archive DA (|DA| = N) keeps the Pareto non-dominated solutions
and, when it overflows, first takes the solutions with a minimal or maximal objective value and then repeatedly adds the
solution farthest (max-min) from the selected ones under the L_p distance with p = 1/m (Algorithm 3, Section III-C2).
Reproduction (Fig. 2, Section IV-E): crossover between CA and DA (one parent from each) and mutation on CA only, as two
independent operators; ceil(N/2) offspring by crossover and N - ceil(N/2) by mutation, so N evaluations per generation.
The output is DA (Section III-A).
"""
import math

import numpy as np

from pymoo.core.algorithm import Algorithm
from pymoo.core.initialization import Initialization
from pymoo.core.population import Population
from pymoo.core.repair import NoRepair
from pymoo.util.display.multi import MultiObjectiveOutput

try:
    from moeas._twoarch_common import eps_truncate, nondominated_mask, dominance_tournament, lp_distance_matrix
except ImportError:                                     # imported as a top-level module
    from _twoarch_common import eps_truncate, nondominated_mask, dominance_tournament, lp_distance_matrix


def update_ca(F, ca_size):
    """Indices of F kept in CA: all if they fit, else Algorithm 2 (I_eps+ fitness, iterative removal)."""
    return eps_truncate(F, ca_size)


def update_da(F, da_size, p, rng):
    """Indices of F kept in DA (Section III-C, Algorithm 3)."""
    nd = np.flatnonzero(nondominated_mask(F))          # only non-dominated solutions enter DA
    if len(nd) <= da_size:
        return nd
    Fn = F[nd]
    n, m = Fn.shape
    chosen = np.zeros(n, bool)
    chosen[np.argmin(Fn, axis=0)] = True                # line 3: solutions with minimal ...
    chosen[np.argmax(Fn, axis=0)] = True                # ... or maximal objective values
    if chosen.sum() > da_size:                           # only if N < 2m: drop random boundary solutions (PlatEMO)
        c = np.flatnonzero(chosen)
        chosen[rng.choice(c, size=len(c) - da_size, replace=False)] = False
        return nd[chosen]
    # lines 4-9: Similarity[i] = min_j dist(i, j) over the selected j; move argmax to DA
    D = lp_distance_matrix(Fn, Fn, p)
    mind = D[:, chosen].min(axis=1)
    while chosen.sum() < da_size:
        cand = np.where(chosen, -np.inf, mind)
        i = int(np.argmax(cand))
        chosen[i] = True
        mind = np.minimum(mind, D[:, i])
    return nd[chosen]


class TwoArch2(Algorithm):

    def __init__(self, pop_size=100, sampling=None, crossover=None, mutation=None, repair=None, ca_size=None,
                 da_size=None, p=None, output=MultiObjectiveOutput(), **kwargs):
        super().__init__(output=output, **kwargs)
        self.pop_size = pop_size
        self.ca_size = pop_size if ca_size is None else ca_size      # Section IV-C: CA with 100 solutions (= N)
        self.da_size = pop_size if da_size is None else da_size      # Section IV-C: DA of the population size
        self.p = p                                                   # Section III-C2: p = 1/m (set in _setup)
        self.crossover, self.mutation = crossover, mutation
        self.repair = repair if repair is not None else NoRepair()
        self.initialization = Initialization(sampling, repair=self.repair)
        self.CA = self.DA = None

    def _setup(self, problem, **kwargs):
        if self.p is None:
            self.p = 1.0 / problem.n_obj

    def _initialize_infill(self):
        return self.initialization.do(self.problem, self.pop_size, algorithm=self, random_state=self.random_state)

    def _update(self, new):
        CA = new if self.CA is None else Population.merge(self.CA, new)
        DA = new if self.DA is None else Population.merge(self.DA, new)
        self.CA = CA[update_ca(CA.get("F"), self.ca_size)]
        self.DA = DA[update_da(DA.get("F"), self.da_size, self.p, self.random_state)]
        self.pop = self.DA

    def _initialize_advance(self, infills=None, **kwargs):
        self._update(infills)

    def _infill(self):
        rng, N = self.random_state, self.pop_size
        n_c = math.ceil(N / 2)
        n_m = N - n_c
        Fca = self.CA.get("F")
        # crossover between CA and DA: parent 1 from CA by dominance tournament, parent 2 uniformly from DA
        a = dominance_tournament(Fca, n_c, rng)
        b = rng.integers(0, len(self.DA), n_c)
        both = Population.merge(self.CA, self.DA)
        parents = np.column_stack([a, len(self.CA) + b])
        off_c = self.crossover(self.problem, both, parents=parents, random_state=rng)
        off_c = off_c[:n_c]                                 # one child per pair (the first child of each mating)
        # mutation on CA only: uniformly chosen CA members, mutated copies
        parts = [Population.new(X=off_c.get("X"))]
        if n_m > 0:
            pm = self.CA[rng.integers(0, len(self.CA), n_m)]
            off_m = self.mutation(self.problem, Population.new(X=pm.get("X").copy()), random_state=rng)
            parts.append(Population.new(X=off_m.get("X")))
        off = Population.merge(*parts)
        off = self.repair(self.problem, off, random_state=rng)
        assert len(off) == N
        return off

    def _advance(self, infills=None, **kwargs):
        self._update(infills)

    def _set_optimum(self):
        self.opt = self.DA                                  # Section III-A: DA is the final output


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs):
    """Two_Arch2 with |CA| = |DA| = pop_size and p = 1/m; ref_dirs are not used (the algorithm needs none)."""
    return TwoArch2(pop_size=pop_size, sampling=sampling, crossover=crossover, mutation=mutation, repair=repair)
