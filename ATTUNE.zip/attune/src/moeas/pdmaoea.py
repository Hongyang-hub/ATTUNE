"""PDMaOEA: many-objective evolutionary algorithm based on parallel distance (Wei, Wang, Wang, Zhang, Cui, Wang, Peng &
Zhao, Swarm and Evolutionary Computation 86:101539, 2024, doi:10.1016/j.swevo.2024.101539), implemented from the paper for
pymoo 0.6.2.

NSGA-II framework (Algorithm 3) with
  Div_i = sum_{j=1..q} e^{-j} * d_ij                           Eq. (2), d_ij = parallel distance to the j-th nearest
  d_ij  = sqrt( sum_h (f_h(x_i)-f_h(x_j))^2 - (sum_h (f_h(x_i)-f_h(x_j)))^2 / M )   Eq. (3), objectives normalised by Eq. (4)
  CS_i  = Div~_i / Cov~_i,  Cov_i = |f(x_i) - z*|               Eqs. (5)-(6), ~ = normalised (min-max) values
  mating selection, Algorithm 1: binary tournament; different fronts -> the better front; both in F1 -> larger Div;
      both in the same front F_k, k > 1 -> larger CS
  environmental selection, Algorithm 2: |F1| >= N -> the N best by Div of F1; otherwise F1..F_(l-1) plus the
      N - |F1..F_(l-1)| best by CS of the critical front F_l
Larger Div (more isolated) and larger CS (isolated and close to the ideal point) are better: Algorithm 2 sorts both in
descending order. Div and CS of a solution are computed within its own front (as NSGA-II's crowding distance).

Note: Algorithm 2 keeps the first N of one descending sort. By default this implementation
instead deletes the member with the smallest metric one at a time and recomputes the metric of the rest (iterative=True).
Only the iterative truncation reproduces the paper's own Table 3 (e.g. DTLZ5/DTLZ6/IDTLZ1, M = 3: within 10% of the
reported means; the literal one-shot sort is 1.3-2.6 times worse). iterative=False gives the literal Algorithm 2.
"""
import numpy as np

from pymoo.algorithms.base.genetic import GeneticAlgorithm
from pymoo.core.duplicate import NoDuplicateElimination
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.core.survival import Survival
from pymoo.operators.selection.tournament import TournamentSelection
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting

Q = 8            # number of nearest neighbours in Div, Section 4.2 (q = 8 chosen by the Friedman test, used in the paper)
EPS = 1e-12


# ----------------------------------------------------------------------------------------------- metrics
def minmax(F):
    """Eq. (4): (f - f_min) / (f_max - f_min) per column over the given set (a constant column becomes 0)."""
    lo, hi = F.min(axis=0), F.max(axis=0)
    return (F - lo) / np.where(hi - lo > EPS, hi - lo, 1.0)


def parallel_distance(Fn):
    """Eq. (3): Euclidean distance between the projections of two points onto a hyperplane with normal (1,...,1)."""
    diff = Fn[:, None, :] - Fn[None, :, :]
    M = Fn.shape[1]
    d2 = np.sum(diff ** 2, axis=2) - np.sum(diff, axis=2) ** 2 / M
    return np.sqrt(np.maximum(d2, 0.0))


def div_metric(F, q=Q):
    """Eq. (2) for the objective vectors F of one set (normalised with Eq. (4) over that set). With fewer than q other
    members, all of them are used."""
    n = len(F)
    if n <= 1:
        return np.zeros(n)
    D = parallel_distance(minmax(F))
    np.fill_diagonal(D, np.inf)
    k = min(q, n - 1)
    Ds = np.sort(D, axis=1)[:, :k]
    return Ds @ np.exp(-np.arange(1, k + 1))


def cs_metric(F, zstar, q=Q, norm="minmax"):
    """Eq. (5): CS = Div~ / Cov~, Div computed within the set, Cov = Euclidean distance of the raw objective vector to the
    ideal point z* (Eq. (6)). norm="minmax" (default): Div~, Cov~ min-max normalised over the set, with EPS added to
    numerator and denominator (the member closest to z* has Cov~ = 0 and therefore the largest CS; 0/0 becomes 1).
    norm="max": division by the maximum (diagnostic; the ranking is then that of Div / Cov)."""
    div = div_metric(F, q)
    cov = np.sqrt(np.sum((F - zstar) ** 2, axis=1))
    if norm == "max":
        return (div / max(div.max(), EPS)) / np.maximum(cov / max(cov.max(), EPS), EPS)
    dn = minmax(div[:, None])[:, 0]
    cn = minmax(cov[:, None])[:, 0]
    return (dn + EPS) / (cn + EPS)


def front_metrics(F, q=Q, norm="minmax"):
    """Front rank of every solution of P_t; Div for the members of F1 and CS for the members of the other fronts (each
    computed within its own front, z* = ideal point of P_t), as needed by Algorithm 1."""
    fronts = NonDominatedSorting().do(F)
    rank = np.empty(len(F), dtype=int)
    score = np.empty(len(F))
    zstar = F.min(axis=0)
    for r, fr in enumerate(fronts):
        rank[fr] = r
        score[fr] = div_metric(F[fr], q) if r == 0 else cs_metric(F[fr], zstar, q, norm)
    return rank, score


# ----------------------------------------------------------------------------------------------- operators
def pd_tournament(pop, P, random_state=None, algorithm=None, **kwargs):
    """Algorithm 1: x1, x2 drawn at random from P_t; different fronts -> the one in the better front; same front ->
    larger Div (front 1) or larger CS (other fronts); exact ties broken at random."""
    q, norm = (algorithm.q, algorithm.cs_norm) if algorithm is not None else (Q, "minmax")
    rank, score = front_metrics(pop.get("F"), q, norm)
    a, b = P[:, 0], P[:, 1]
    S = np.where(rank[a] < rank[b], a, b)
    same = rank[a] == rank[b]
    sa, sb = score[a], score[b]
    S = np.where(same & (sa > sb), a, S)
    S = np.where(same & (sa < sb), b, S)
    tie = same & (sa == sb)
    if tie.any():
        coin = random_state.random(tie.sum()) < 0.5
        S[tie] = np.where(coin, a[tie], b[tie])
    return S


class PDSurvival(Survival):
    """Algorithm 2 (environmental selection)."""

    def __init__(self, q=Q, iterative=True, cs_norm="minmax", iterative_cs=None):
        super().__init__(filter_infeasible=True)
        self.q, self.iterative, self.cs_norm = q, iterative, cs_norm
        self.iterative_cs = iterative if iterative_cs is None else iterative_cs

    def _best(self, F, k, metric, iterative):
        """Indices of the k best rows of F by the metric: deletion of the worst member one at a time with recomputation
        of the metric of the remaining members (iterative=True, default), or one descending sort as literally written in
        Algorithm 2, lines 7-8 and 11-12 (iterative=False)."""
        if not iterative:
            return np.argsort(-metric(F), kind="stable")[:k]
        alive = np.arange(len(F))
        while len(alive) > k:
            alive = np.delete(alive, int(np.argmin(metric(F[alive]))))
        return alive

    def _do(self, problem, pop, n_survive=None, random_state=None, **kwargs):
        F = pop.get("F")
        fronts = NonDominatedSorting().do(F)
        if len(fronts[0]) >= n_survive:                           # |F1| >= N: N largest Div of F1
            f1 = fronts[0]
            return pop[f1[self._best(F[f1], n_survive, lambda G: div_metric(G, self.q), self.iterative)]]
        keep = []
        for fr in fronts:                                         # F1 u ... u F_(l-1)
            if len(keep) + len(fr) >= n_survive:
                fl = fr
                break
            keep.extend(fr)
        need = n_survive - len(keep)
        keep = np.array(keep, dtype=int)
        if need == len(fl):
            return pop[np.concatenate([keep, fl])]
        z = F.min(axis=0)                                         # ideal point z* of R_t
        best = self._best(F[fl], need, lambda G: cs_metric(G, z, self.q, self.cs_norm), self.iterative_cs)
        return pop[np.concatenate([keep, fl[best]])]


class PDMaOEA(GeneticAlgorithm):
    def __init__(self, pop_size=100, sampling=None, crossover=None, mutation=None, repair=None, q=Q, iterative=True,
                 cs_norm="minmax", iterative_cs=None, **kwargs):
        self.q, self.cs_norm = q, cs_norm
        super().__init__(pop_size=pop_size, sampling=FloatRandomSampling() if sampling is None else sampling,
                         selection=TournamentSelection(func_comp=pd_tournament), crossover=crossover,
                         mutation=mutation, survival=PDSurvival(q, iterative, cs_norm, iterative_cs), repair=repair,
                         eliminate_duplicates=NoDuplicateElimination(), advance_after_initial_infill=False, **kwargs)


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs):
    """PDMaOEA uses no reference vectors (solution-to-solution diversity); ref_dirs is unused."""
    return PDMaOEA(pop_size=pop_size, sampling=sampling, crossover=crossover, mutation=mutation, repair=repair)
