"""NSGA-II with the truthful crowding distance (NSGA-II-T).

Zheng W., Gao Y., Doerr B. A crowding distance that provably solves the difficulties of the NSGA-II in many-objective
optimization. IEEE Transactions on Evolutionary Computation, 2026. doi:10.1109/TEVC.2025.3638306 (arXiv:2407.17687).

The algorithm is the NSGA-II (Algorithm 1 of the paper) with the classic crowding distance replaced by the truthful
crowding distance tCD (Section 3.2, Algorithm 2). Minimisation is handled by sorting each objective in ascending order
(the paper maximises and sorts in descending order), so the best individual of each objective gets tCD = +inf.
Sorting is stable on one common index order, which gives the correlated tie-breaking the paper assumes.

`sequential=False` (default) is the NSGA-II-T: tCD is computed once on the critical front and the N_r individuals with
the smallest tCD are removed, ties broken at random (Algorithm 1, lines 6-8). `sequential=True` is the sequential
NSGA-II-T: after every removal the tCD of the remaining critical-front individuals is recomputed (Algorithm 1, line 9).
Mating selection and variation are those of pymoo's NSGA-II (binary tournament: dominance, then crowding distance,
here the truthful one; SBX and polynomial mutation as passed in).
`crowding="classic"` switches the truthful crowding distance off (pymoo's crowding distance, used only to check that
the survival code reproduces pymoo's NSGA2 exactly).
"""
import numpy as np

from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.core.survival import Survival
from pymoo.operators.survival.rank_and_crowding.metrics import get_crowding_function
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
from pymoo.util.randomized_argsort import randomized_argsort


def _tcd_distinct(F):
    """Algorithm 2 on a set of distinct objective vectors F (n x m), rows in the common tie-breaking order,
    minimisation (ascending sorts). Returns the n tCD values."""
    n, m = F.shape
    rng = F.max(axis=0) - F.min(axis=0)                     # f_a(S_a.1) - f_a(S_a.|S|)
    Fn = F / np.where(rng > 0, rng, 1.0)                    # "0/0" summands count as zero (numerator is 0 too)
    D = np.zeros((n, n))
    for a in range(m):                                      # normalised L1 distance d(., .)
        D += np.abs(Fn[:, a, None] - Fn[None, :, a])
    tcd = np.zeros(n)
    later = np.triu(np.ones((n, n), dtype=bool))            # positions k >= j are not "earlier"
    for i in range(m):
        order = np.argsort(F[:, i], kind="stable")          # ascending f_i, ties in the common order (correlated)
        Dp = D[np.ix_(order, order)]
        Dp[later] = np.inf
        tcd[order] += Dp.min(axis=1)                        # min_{k<j} d(S_i.k, S_i.j); the first one gets +inf
    return tcd


def truthful_crowding_distance(F):
    """Truthful crowding distance (Algorithm 2) of the rows of F (pairwise non-dominated objective vectors, minimised).

    The common tie-breaking order is the row order. Copies of an objective vector after its first occurrence have
    tCD = 0 (Lemma 1), and they do not change the tCD of any other row (a copy is at the same distance as its first
    occurrence and comes later in every sorting), so tCD is computed on the distinct vectors kept in the order of
    their first occurrence, which is exactly Algorithm 2 on all rows and much cheaper when there are many copies."""
    F = np.asarray(F, dtype=float)
    n = len(F)
    if n == 0:
        return np.zeros(0)
    _, first = np.unique(F, axis=0, return_index=True)
    first = np.sort(first)                                  # distinct vectors in order of first occurrence
    tcd = np.zeros(n)
    tcd[first] = _tcd_distinct(F[first])
    return tcd


class TruthfulSurvival(Survival):
    """Non-dominated sorting, then truncation of the critical front by the truthful crowding distance."""

    def __init__(self, sequential=False, crowding="truthful", nds=None):
        super().__init__(filter_infeasible=True)
        self.sequential, self.crowding = sequential, crowding
        self.nds = nds if nds is not None else NonDominatedSorting()
        self._cd = get_crowding_function("cd") if crowding == "classic" else None

    def _dist(self, F, n_remove):
        return self._cd.do(F, n_remove=n_remove) if self._cd is not None else truthful_crowding_distance(F)

    def _sequential_keep(self, F, n_remove, random_state):
        """Remove n_remove rows one at a time, each time a row with the smallest current tCD (random among ties),
        recomputing tCD after every removal. Rows with tCD = 0 are copies; removing one changes no other tCD, so a
        run of k removals at tCD = 0 is a uniformly random k-subset of them (the same distribution as k single steps)."""
        keep = np.arange(len(F))
        cd = truthful_crowding_distance(F)
        zero = np.flatnonzero(cd == 0)
        if len(zero):
            k = min(n_remove, len(zero))
            drop = random_state.choice(zero, size=k, replace=False)
            keep = np.setdiff1d(keep, drop)
            n_remove -= k
        for _ in range(n_remove):
            cd = truthful_crowding_distance(F[keep])
            cand = np.flatnonzero(cd == cd.min())
            keep = np.delete(keep, cand[random_state.integers(len(cand))])
        return keep

    def _do(self, problem, pop, *args, n_survive=None, random_state=None, **kwargs):
        F = pop.get("F").astype(float, copy=False)
        fronts = self.nds.do(F, n_stop_if_ranked=n_survive)
        survivors = []
        for k, front in enumerate(fronts):
            front = np.asarray(front)
            I = np.arange(len(front))  # noqa: E741
            if len(survivors) + len(front) > n_survive:
                n_remove = len(survivors) + len(front) - n_survive
                if self.sequential and self._cd is None:
                    I = self._sequential_keep(F[front], n_remove, random_state)  # noqa: E741
                    cd = np.zeros(len(front))
                    cd[I] = truthful_crowding_distance(F[front[I]])
                else:
                    # remove the n_remove smallest values, ties at random (Algorithm 1, line 8); same call as pymoo
                    cd = self._dist(F[front], n_remove)
                    I = randomized_argsort(cd, order="descending", method="numpy", random_state=random_state)  # noqa: E741
                    I = I[:-n_remove]  # noqa: E741
            else:
                cd = self._dist(F[front], 0)
            for j, i in enumerate(front):
                pop[i].set("rank", k)
                pop[i].set("crowding", cd[j])
            survivors.extend(front[I])
        return pop[survivors]


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs, sequential=False, crowding="truthful"):
    """NSGA-II-T. ref_dirs is not used (the truthful crowding distance needs no reference vectors)."""
    return NSGA2(pop_size=pop_size, sampling=sampling, crossover=crossover, mutation=mutation,
                 survival=TruthfulSurvival(sequential=sequential, crowding=crowding), repair=repair,
                 eliminate_duplicates=False)
