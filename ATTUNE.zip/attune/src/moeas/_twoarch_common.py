"""Pieces shared by Two_Arch2 (src/moeas/twoarch2.py) and MaOEA-HAP (src/moeas/maoeahap.py).

* the I_eps+ convergence archive of Two_Arch2 (Wang, Jiao, Yao 2015, Section III-B, Eq. (1)-(2), Algorithm 2), which
  MaOEA-HAP reuses as its elite archive (Yue et al. 2026, Section 3.2, Eq. (2)-(3), Algorithm 2);
* the dominance-based binary tournament on that archive used to pick its mating parents (PlatEMO's Two_Arch2
  MatingSelection; MaOEA-HAP Section 3.1 describes the same filter for the elite archive);
* Pareto non-dominance, L_p (p < 1) distances and objective normalisation.

All randomness comes from the generator passed in (the algorithm's random_state).
"""
import numpy as np

from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting

KAPPA = 0.05          # Two_Arch2 Eq. (2) and MaOEA-HAP Eq. (3)


def normalize(F):
    """Eq. (4)-(6) of MaOEA-HAP: (f - z*) / (z_nad - z*) with ideal and nadir of the set; a constant objective -> 0."""
    F = np.asarray(F, float)
    lo, hi = F.min(axis=0), F.max(axis=0)
    rng = np.where(hi > lo, hi - lo, 1.0)
    return (F - lo) / rng


def eps_indicator_matrix(F):
    """I[a, b] = I_eps+(x_a, x_b) = max_i (f_i(x_a) - f_i(x_b)), Eq. (1) of Two_Arch2: the smallest eps by which x_a
    has to be translated so that it weakly dominates x_b."""
    return (F[:, None, :] - F[None, :, :]).max(axis=2)


def eps_fitness(F, kappa=KAPPA):
    """Fitness of Eq. (2) (Two_Arch2) / Eq. (3) (MaOEA-HAP), F(x1) = sum_{x2 != x1} -exp(-I(x2, x1) / kappa), on objectives
    normalised to [0, 1] and with IBEA's adaptive scale c = max |I| (Zitzler & Kuenzli 2004, adaptive IBEA; with min-max
    normalisation c = 1 whenever the set has two distinct objective vectors). Returns (fitness, E) with
    E[a, b] = exp(-I(x_a, x_b) / (c kappa)), so that removing x* adds E[x*] to everyone's fitness (Algorithm 2, line 5)."""
    Fn = normalize(F)
    I = eps_indicator_matrix(Fn)                       # noqa: E741
    c = np.abs(I).max()
    if c == 0:
        c = 1.0
    E = np.exp(-I / (c * kappa))
    fit = -(E.sum(axis=0) - np.diag(E))
    return fit, E


def eps_truncate(F, n_keep, kappa=KAPPA):
    """Algorithm 2 of Two_Arch2 ('selection in an overflowed CA') = Algorithm 2 of MaOEA-HAP ('UpdateElite'): while the
    archive is too large, delete the member with the smallest fitness and add exp(-I(x*, x)/kappa) to the others.
    Returns the sorted indices of the members kept. Ties: the first index (MATLAB min)."""
    n = len(F)
    if n <= n_keep:
        return np.arange(n)
    fit, E = eps_fitness(F, kappa)
    alive = np.ones(n, bool)
    for _ in range(n - n_keep):
        worst = int(np.argmin(np.where(alive, fit, np.inf)))
        alive[worst] = False
        fit = fit + E[worst]
    return np.flatnonzero(alive)


def nondominated_mask(F):
    """Pareto non-dominated members (identical objective vectors do not dominate each other, so duplicates are kept)."""
    m = np.zeros(len(F), bool)
    m[NonDominatedSorting().do(np.asarray(F, float), only_non_dominated_front=True)] = True
    return m


def dominates(Fa, Fb):
    """Row-wise Pareto dominance of Fa over Fb (minimisation)."""
    return np.all(Fa <= Fb, axis=1) & np.any(Fa < Fb, axis=1)


def dominance_tournament(F, n, rng):
    """Binary tournament on an archive by Pareto dominance (PlatEMO Two_Arch2/MatingSelection; MaOEA-HAP Section 3.1):
    two members drawn uniformly with replacement; the first is taken if it dominates the second, otherwise the second
    (i.e. the dominating one, or a random one of a mutually non-dominated pair)."""
    a = rng.integers(0, len(F), n)
    b = rng.integers(0, len(F), n)
    return np.where(dominates(F[a], F[b]), a, b)


def lp_distance_matrix(A, B, p):
    """(sum_i |a_i - b_i|^p)^(1/p) for all pairs; p < 1 gives the fractional distances of Two_Arch2 Section III-C."""
    D = (np.abs(A[:, None, :] - B[None, :, :]) ** p).sum(axis=2)
    return D ** (1.0 / p)
