"""Adaptive IBEA with the additive epsilon indicator (IBEA_eps+), implemented from

    E. Zitzler, S. Kuenzli. Indicator-Based Selection in Multiobjective Search. PPSN VIII, LNCS 3242:832-842, 2004.
    doi:10.1007/978-3-540-30217-9_84

Algorithm 1 (basic IBEA) with the adaptive scaling of Algorithm 2 (Section 4.1), kappa = 0.05 (Section 4.1).
One generation: binary tournament with replacement on fitness fills a mating pool of pop_size parents (Step 5), the
given crossover and mutation create pop_size offspring (Step 6), and environmental selection on the union of
population and offspring removes the worst individual one at a time with fitness updates (Steps 2-3).
adaptive=False gives the basic IBEA of Algorithm 1.
"""
import numpy as np

from pymoo.algorithms.base.genetic import GeneticAlgorithm
from pymoo.core.selection import Selection
from pymoo.core.survival import Survival
from pymoo.util.display.multi import MultiObjectiveOutput

KAPPA = 0.05


def eps_indicator_matrix(F):
    """I[a, b] = I_eps+({x_a}, {x_b}) = max_i (f_i(x_a) - f_i(x_b)): the smallest eps by which x_a must be translated
    so that it weakly dominates x_b (Section 2)."""
    return (F[:, None, :] - F[None, :, :]).max(axis=2)


class IndicatorSurvival(Survival):
    """Steps 2 and 3 of Algorithm 2: adaptive fitness assignment and iterative removal of the worst individual."""

    def __init__(self, kappa=KAPPA, adaptive=True):
        super().__init__(filter_infeasible=False)
        self.kappa, self.adaptive = kappa, adaptive

    def _do(self, problem, pop, *args, n_survive=None, random_state=None, **kwargs):
        F = pop.get("F").astype(float)
        if self.adaptive:
            # Step 2.1-2.2: scale each objective to [0, 1] with the population's lower and upper bounds
            lb, ub = F.min(axis=0), F.max(axis=0)
            rng = np.where(ub > lb, ub - lb, 1.0)        # constant objective: all scaled values 0
            Fs = (F - lb) / rng
            # Step 2.3: indicator values on scaled objectives and c = max |I|
            I = eps_indicator_matrix(Fs)                   # noqa: E741
            c = np.abs(I).max()
            if c == 0:                                     # all objective vectors identical
                c = 1.0
        else:
            # Algorithm 1 (basic IBEA, B-IBEA): raw objectives, no indicator scaling (c = 1); only for validation
            I, c = eps_indicator_matrix(F), 1.0            # noqa: E741
        E = np.exp(-I / (c * self.kappa))                  # E[a, b] = exp(-I({x_a}, {x_b}) / (c kappa))
        # Step 2.4: F(x1) = sum_{x2 != x1} -exp(-I({x2}, {x1}) / (c kappa))
        np.fill_diagonal(E, 0.0)                           # x2 != x1 (exact; no cancellation)
        fit = -E.sum(axis=0)
        alive = np.ones(len(pop), dtype=bool)
        # Step 3: remove the individual with the smallest fitness, update the others, until |P| = n_survive
        for _ in range(len(pop) - n_survive):
            cand = np.where(alive, fit, np.inf)
            worst = int(np.argmin(cand))
            alive[worst] = False
            fit += E[worst]                                # F(x) = F(x) + exp(-I({x*}, {x}) / (c kappa))
        idx = np.where(alive)[0]
        survivors = pop[idx]
        survivors.set("fitness", fit[idx])
        return survivors


class FitnessBinaryTournament(Selection):
    """Step 5: binary tournament selection with replacement on P (larger fitness wins; on a tie the first drawn)."""

    def _do(self, problem, pop, n_select, n_parents, random_state=None, **kwargs):
        fit = pop.get("fitness")
        n = n_select * n_parents
        a = random_state.integers(0, len(pop), size=n)
        b = random_state.integers(0, len(pop), size=n)
        winner = np.where(fit[b] > fit[a], b, a)
        return winner.reshape(n_select, n_parents)


class IBEA(GeneticAlgorithm):
    def __init__(self, pop_size=100, sampling=None, crossover=None, mutation=None, repair=None, kappa=KAPPA,
                 adaptive=True, output=MultiObjectiveOutput(), **kwargs):
        super().__init__(pop_size=pop_size, sampling=sampling, selection=FitnessBinaryTournament(),
                         crossover=crossover, mutation=mutation, survival=IndicatorSurvival(kappa, adaptive),
                         n_offsprings=pop_size, eliminate_duplicates=False, repair=repair,
                         advance_after_initial_infill=True,       # Steps 2-3 on the initial population
                         output=output, **kwargs)

    def _setup(self, problem, **kwargs):
        assert not problem.has_constraints(), "IBEA here is for unconstrained problems"

    def _infill(self):
        off = super()._infill()
        assert len(off) == self.n_offsprings, "IBEA must create exactly pop_size offspring per generation"
        return off


def make(sampling, repair, crossover, mutation, pop_size, ref_dirs):
    """ref_dirs is not used by IBEA."""
    return IBEA(pop_size=pop_size, sampling=sampling, crossover=crossover, mutation=mutation, repair=repair)
