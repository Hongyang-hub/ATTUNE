"""Loading of NLST501: findings with the automated solid component, reads, outcomes and folds."""
import json
import os

import numpy as np
import pandas as pd

from rules import Variant, nodule_table

ROOT = os.path.join(os.path.dirname(__file__), "..")
SOLID_COLS = {"-300 HU": ("solid300_mean_mm", 1.0), "-200 HU": ("solid200_mean_mm", 1.0),
              "-300 HU / 0.81": ("solid300_mean_mm", 0.81)}


def load(measure="-300 HU"):
    """Returns (nod, reads, cancer, fold). nod['solid'] = solid-component diameter in mm (NaN without a mask);
    '/0.81' divides it by 0.81 (partial-volume correction). The component is capped at the recorded total size, as in
    the LR-full definition. fold: -1 = test set."""
    p = lambda *a: os.path.join(ROOT, *a)  # noqa: E731
    ann = pd.read_csv(p("data/raw/nlst501/LIDC-annot-NLST501-annotations.csv"))
    pat = pd.read_csv(p("data/raw/nlst501/LIDC-annot-NLST501-patients.csv"))
    cancer = pat.set_index("pid").nlst_diagnosis.eq("cancer")
    reads = ann[["pid", "db"]].drop_duplicates().reset_index(drop=True)
    fold = {int(k): f for k, f in json.load(open(p("data/splits.json")))["fold"].items()}
    nod = nodule_table(ann, Variant())
    col, scale = SOLID_COLS[measure]
    sc = pd.read_csv(p("data/derived/solid_component.csv"))
    key = ["pid", "db", "series_uid", "finding_id"]
    s = nod[key].merge(sc[key + [col]], on=key, how="left")[col].to_numpy()
    nod = nod.assign(solid=np.minimum(s / scale, nod["size"].to_numpy()))
    return nod, reads, cancer, fold


def pids_in(fold, folds):
    return [p for p, f in fold.items() if f in set(folds)]


def design_folds(design, outer=-1):
    """main: search folds 0-2, selection folds 3-4. nested k: outer fold k evaluated, (k+1) % 5 selects, rest search."""
    if design == "main":
        return [0, 1, 2], [3, 4], [-1]
    sel = (outer + 1) % 5
    return sorted(set(range(5)) - {outer, sel}), [sel], [outer]
