"""Coding of the radiologist findings of NLST501 (one row per target lesion or mass of one read).

Management levels (ordinal):
    0 = routine annual LDCT (Lung-RADS 1/2)
    1 = 6-month LDCT (Lung-RADS 3)
    2 = 3-month LDCT or PET/CT (Lung-RADS 4A)
    3 = diagnostic work-up (Lung-RADS 4B/4X)
"""
from dataclasses import dataclass

import pandas as pd

SOLID, PART, GGO = "solid", "part", "ggo"
TEXTURE = {"Solid": SOLID, "Part Solid/Mixed": PART, "GGO / Non-Solid": GGO}
SPIC = {"No Spiculation / Nearly No Spiculation": 0, "Medium Spiculation": 1,
        "Marked Spiculation / Near Marked Spiculation": 2}
LOBU = {"No Lobulation and Nearly no": 0, "Medium Lobulation": 1,
        "Marked Lobulation / Near Marked Lobulation": 2}
MARGIN = {"Sharp / Near Sharp": 0, "Medium Margin": 1, "Poorly Defined / Near Poorly Defined": 2}
SPHER = {"Round / Ovoid-Round": 0, "Ovoid": 1, "Linear / Ovoid-Linear": 2}


@dataclass(frozen=True)
class Variant:
    size_col: str = "reported_measure"
    benign_calc: tuple = ("Popcorn", "Laminated", "Solid", "Central")


def nodule_table(ann: pd.DataFrame, v: Variant = Variant()) -> pd.DataFrame:
    """One row per TL/Mass finding with coded features; uncharacterised texture is treated as solid."""
    t = ann[ann.finding_type.isin(["TL", "Mass"])].copy()
    size = t["reported_measure"].astype(float)
    if v.size_col != "reported_measure":
        alt = t[v.size_col].astype(float)
        size = alt.where(alt.notna(), size)
    t["size"] = size
    t["tex"] = t.tl_texture.map(TEXTURE).fillna(SOLID)
    t["spic"] = t.tl_spiculation.map(SPIC).fillna(0).astype(int)
    t["lobu"] = t.tl_lobulation.map(LOBU).fillna(0).astype(int)
    t["margin"] = t.tl_margin.map(MARGIN).fillna(0).astype(int)
    t["spher"] = t.tl_sphericity.map(SPHER).fillna(0).astype(int)
    t["benign_calc"] = t.tl_calcification.isin(v.benign_calc)
    return t[["pid", "db", "series_uid", "finding_id", "finding_type", "size", "tex", "spic", "lobu", "margin", "spher",
              "benign_calc"]]
