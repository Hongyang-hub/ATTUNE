"""Rule tables, their repair, and their vectorised evaluation on a set of participants.

Genome (14 integers):
    0-2   solid nodule thresholds (size, mm) for 6-month LDCT, 3-month LDCT/PET, work-up
    3     part-solid nodule recall threshold (total size) -> 6-month LDCT
    4-5   part-solid nodule thresholds on the solid component -> 3-month LDCT/PET, work-up
    6-8   ground-glass nodule thresholds (size) for 6-month LDCT, 3-month LDCT/PET, work-up
          thresholds: value g -> 4.0 + 0.5 g mm (4-30 mm); g = GRID_NEVER means "never reached"
    9     spiculation: 0 off, 1 medium+ -> work-up, 2 marked -> work-up, 3 medium+ -> 3-month, 4 marked -> 3-month
    10    lobulation: same coding
    11    poorly defined margin: 0 off, 1 -> 3-month, 2 -> work-up
    12    linear / ovoid-linear shape -> one level down (0/1)
    13    benign calcification -> routine (0/1)
Modifiers 9-11 act only on findings already at 6-month LDCT or above by size. A read's level is the highest level of its
findings (0 without findings).

Repair (escalation capped at the thresholds of Lung-RADS v2022; recall thresholds are free): solid 3-month <= 8 mm and work-up <= 15 mm; part-solid solid component
3-month <= 6 mm and work-up <= 8 mm; medium or marked spiculation -> work-up; thresholds ordered within each row.
"""
import numpy as np

GRID_MAX = 52                  # 4.0 .. 30.0 mm
GRID_NEVER = 53
N_GENES = 14
XL = np.zeros(N_GENES, int)
XU = np.array([GRID_NEVER] * 9 + [4, 4, 2, 1, 1])
LEVELS = ("routine annual LDCT", "6-month LDCT", "3-month LDCT or PET/CT", "diagnostic work-up")


def mm(g):
    return np.where(np.asarray(g) >= GRID_NEVER, np.inf, 4.0 + 0.5 * np.asarray(g))


MODS = {
    "spiculation": ["off", "medium or marked -> work-up", "marked -> work-up", "medium or marked -> 3-month", "marked -> 3-month"],
    "lobulation": ["off", "medium or marked -> work-up", "marked -> work-up", "medium or marked -> 3-month", "marked -> 3-month"],
    "poorly_defined_margin": ["off", "-> 3-month", "-> work-up"],
    "linear_shape_down_one_level": ["no", "yes"],
    "benign_calcification_to_routine": ["no", "yes"],
}


def _v(x):
    x = float(x)
    return None if not np.isfinite(x) else (int(x) if x == int(x) else x)


def to_json(g):
    """Readable form of a genome: thresholds in mm (None = never reached) and the modifier settings."""
    t = mm(np.asarray(g[:9]))
    d = {"solid": [_v(x) for x in t[0:3]],
         "part_solid": [_v(t[3]), _v(t[4]), _v(t[5])],
         "ground_glass": [_v(x) for x in t[6:9]]}
    for j, (k, opts) in enumerate(MODS.items()):
        d[k] = opts[int(g[9 + j])]
    return d


def to_grid(x_mm):
    return GRID_NEVER if x_mm is None or not np.isfinite(x_mm) or x_mm > 30 else int(np.clip(round((x_mm - 4.0) / 0.5), 0, GRID_MAX))


def lra_genome():
    """Approximate Lung-RADS v2022 without the solid component: solid 6/8/15 mm; part-solid >= 6 mm -> 6-month LDCT;
    ground-glass >= 30 mm -> 6-month LDCT; medium+ spiculation -> work-up; benign calcification -> routine."""
    g = [to_grid(v) for v in (6, 8, 15, 6, np.inf, np.inf, 30, np.inf, np.inf)]
    return np.array(g + [1, 0, 0, 0, 1])


def lrfull_genome():
    """Lung-RADS v2022 with the solid component (LR-full): part-solid >= 6 mm total -> 6-month LDCT, solid component
    >= 6 mm -> 3-month LDCT/PET, >= 8 mm -> work-up; otherwise as lra_genome()."""
    g = lra_genome().copy()
    g[3:6] = [to_grid(6), to_grid(6), to_grid(8)]
    return g


def repair(X):
    X = np.clip(np.asarray(X, int).copy(), XL, XU)
    if X.ndim == 1:
        return repair(X[None])[0]
    blk = np.sort(X[:, 0:3], axis=1)
    blk[:, 2] = np.minimum(blk[:, 2], to_grid(15))
    blk[:, 1] = np.minimum(blk[:, 1], np.minimum(to_grid(8), blk[:, 2]))
    blk[:, 0] = np.minimum(blk[:, 0], blk[:, 1])
    X[:, 0:3] = blk
    sb = np.sort(X[:, 4:6], axis=1)
    sb[:, 1] = np.minimum(sb[:, 1], to_grid(8))
    sb[:, 0] = np.minimum(sb[:, 0], np.minimum(to_grid(6), sb[:, 1]))
    X[:, 4:6] = sb
    X[:, 6:9] = np.sort(X[:, 6:9], axis=1)
    X[:, 9] = 1
    return X


class Evaluator:
    """Evaluation of genomes on a fixed set of participants (nod must carry the 'solid' column)."""

    def __init__(self, nod, reads, cancer_by_pid, pids):
        pids = np.asarray(sorted(pids))
        reads = reads[reads.pid.isin(pids)].reset_index(drop=True)
        self.read_key = {k: i for i, k in enumerate(zip(reads.pid, reads.db))}
        n = nod[nod.pid.isin(pids)]
        self.read_idx = np.array([self.read_key[k] for k in zip(n.pid, n.db)], dtype=int)
        self.n_reads = len(reads)
        self.size = n["size"].to_numpy(float)
        self.tex = n.tex.map({"solid": 0, "part": 1, "ggo": 2}).to_numpy()
        self.spic, self.lobu = n.spic.to_numpy(), n.lobu.to_numpy()
        self.margin, self.spher = n.margin.to_numpy(), n.spher.to_numpy()
        self.bcalc = n.benign_calc.to_numpy()
        self.solid = np.nan_to_num(n["solid"].to_numpy(float), nan=-np.inf)   # no mask -> never escalates by component
        self.pids = pids
        pidx = {p: i for i, p in enumerate(pids)}
        self.read_pat = np.array([pidx[p] for p in reads.pid.to_numpy()])
        self.n_per_pat = np.bincount(self.read_pat, minlength=len(pids))
        self.n_pairs = self.n_per_pat * (self.n_per_pat - 1) / 2
        self.cancer = np.array([bool(cancer_by_pid[p]) for p in pids])

    def size_levels(self, g):
        th = mm(np.asarray(g[:9])).reshape(3, 3)[self.tex]
        lvl = (self.size[:, None] >= th).sum(1)
        t = mm(np.asarray(g[3:6]))
        p = self.tex == 1
        return np.where(p, np.maximum.reduce([(self.size >= t[0]).astype(int), 2 * (self.solid >= t[1]), 3 * (self.solid >= t[2])]), lvl)

    def nodule_levels(self, g):
        lvl = self.size_levels(g)
        base = lvl >= 1
        for gene, sev in ((g[9], self.spic), (g[10], self.lobu)):
            if gene:
                need = 1 if gene in (1, 3) else 2
                tgt = 3 if gene in (1, 2) else 2
                lvl = np.where(base & (sev >= need), np.maximum(lvl, tgt), lvl)
        if g[11]:
            lvl = np.where(base & (self.margin >= 2), np.maximum(lvl, 2 if g[11] == 1 else 3), lvl)
        if g[12]:
            lvl = np.where(self.spher == 2, np.maximum(lvl - 1, 0), lvl)
        if g[13]:
            lvl = np.where(self.bcalc, 0, lvl)
        return lvl

    def levels(self, g):
        rl = np.zeros(self.n_reads, int)
        np.maximum.at(rl, self.read_idx, self.nodule_levels(g))
        return rl

    def _pm(self, v):
        return np.bincount(self.read_pat, weights=v, minlength=len(self.pids)) / self.n_per_pat

    def _discord(self, rl):
        """Per participant: share of read pairs with a different recall decision / a different level."""
        cnt = lambda m: np.bincount(self.read_pat, weights=m.astype(float), minlength=len(self.pids))  # noqa: E731
        r = cnt(rl >= 1)
        same = sum(c * (c - 1) / 2 for c in (cnt(rl == k) for k in range(4)))
        with np.errstate(invalid="ignore", divide="ignore"):          # participants with one read: undefined (NaN)
            return r * (self.n_per_pat - r) / self.n_pairs, 1 - same / self.n_pairs

    def patient_rates(self, g, rl=None):
        rl = self.levels(g) if rl is None else rl
        rec, lev = self._discord(rl)
        return {"miss": self._pm(rl == 0), "fp_recall": self._pm(rl >= 1), "under": self._pm((3 - rl) / 3),
                "over": self._pm(rl / 3), "ge3m": self._pm(rl >= 2), "workup": self._pm(rl == 3),
                "recall_disc": rec, "level_disc": lev}

    def objectives(self, g):
        """miss, under-triage (cancers), false-positive recall (non-cancers), recall discordance (all participants)."""
        r = self.patient_rates(g)
        c, nc = self.cancer, ~self.cancer
        return np.array([r["miss"][c].mean(), r["under"][c].mean(), r["fp_recall"][nc].mean(), r["recall_disc"].mean()])

    def constraint_metrics(self, g):
        """miss, under-triage, false-positive recall, non-cancers at 3-month LDCT or beyond, recall discordance."""
        r = self.patient_rates(g)
        c, nc = self.cancer, ~self.cancer
        return np.array([r["miss"][c].mean(), r["under"][c].mean(), r["fp_recall"][nc].mean(), r["ge3m"][nc].mean(),
                         r["recall_disc"].mean()])

    def F(self, X):
        return np.array([self.objectives(g) for g in X])


def select(X, ev_sel, ref_genome):
    """Selection rule: among X, tables whose miss, under-triage, false-positive recall and non-cancers at
    3-month LDCT or beyond on the selection participants are all no higher than those of the reference (LR-full); the one
    with the lowest recall discordance. Returns (genome or None, metrics of X)."""
    M = np.array([ev_sel.constraint_metrics(g) for g in X])
    ref = ev_sel.constraint_metrics(ref_genome)
    ok = np.all(M[:, :4] <= ref[:4] + 1e-12, axis=1)
    if not ok.any():
        return None, M
    i = np.flatnonzero(ok)
    i = i[np.lexsort((np.arange(len(i)), M[i, 4]))][0]
    return X[i], M
