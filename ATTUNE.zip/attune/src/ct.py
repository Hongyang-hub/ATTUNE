"""CT loading and nodule patch extraction."""
from pathlib import Path

import numpy as np
import SimpleITK as sitk


def load_series(series_dir: Path) -> sitk.Image:
    r = sitk.ImageSeriesReader()
    files = r.GetGDCMSeriesFileNames(str(series_dir))
    r.SetFileNames(files)
    return r.Execute()


def patch_mm(img: sitk.Image, center_idx, size=48, spacing=1.0, flip_z=False) -> np.ndarray:
    """size^3 patch (z, y, x) at `spacing` mm around a continuous voxel index (x, y, z) of `img`.
    flip_z: z is an NLST501 annotation slice number - 1-based and counted from the most superior slice, i.e. in the
    opposite order to the sorted series (checked against the dataset's DICOM SEG masks: median offset 0.00 slices)."""
    x, y, z = center_idx
    if flip_z:
        z = img.GetSize()[2] - z
    c = img.TransformContinuousIndexToPhysicalPoint((float(x), float(y), float(z)))
    ref = sitk.Image([size] * 3, sitk.sitkFloat32)
    ref.SetSpacing([spacing] * 3)
    ref.SetDirection(img.GetDirection())
    half = (size - 1) / 2 * spacing
    d = np.array(img.GetDirection()).reshape(3, 3)
    ref.SetOrigin(tuple(np.array(c) - d @ np.array([half] * 3)))
    out = sitk.Resample(img, ref, sitk.Transform(), sitk.sitkLinear, -1024.0, sitk.sitkFloat32)
    return sitk.GetArrayFromImage(out)
