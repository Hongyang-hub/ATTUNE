"""Scan-level metrics. Each patient has one scan read 4 times; each read gets a level;
indicators are averaged over the patient's reads, then over patients.

Definitions:
    miss        cancer, level == 0
    fp_recall   non-cancer, level >= 1
    under       cancer, (3 - level) / 3
    over        non-cancer, level / 3
    nc_workup   non-cancer, level == 3
    c_ge3m      cancer, level >= 2
    nc_ge3m     non-cancer, level >= 2
"""
import numpy as np
import pandas as pd


def per_patient(rl: pd.DataFrame, cancer: pd.Series) -> pd.DataFrame:
    d = rl.copy()
    d["cancer"] = d.pid.map(cancer)
    lv = d.level
    d["miss"] = (lv == 0).astype(float)
    d["fp_recall"] = (lv >= 1).astype(float)
    d["under"] = (3 - lv) / 3
    d["over"] = lv / 3
    d["nc_workup"] = (lv == 3).astype(float)
    d["ge3m"] = (lv >= 2).astype(float)
    return d.groupby("pid").agg(cancer=("cancer", "first"), miss=("miss", "mean"),
                                fp_recall=("fp_recall", "mean"), under=("under", "mean"),
                                over=("over", "mean"), nc_workup=("nc_workup", "mean"),
                                ge3m=("ge3m", "mean"))


def summarise(pp: pd.DataFrame) -> dict:
    c, nc = pp[pp.cancer], pp[~pp.cancer]
    return {"n_c": len(c), "n_nc": len(nc),
            "miss": c.miss.mean(), "under": c.under.mean(), "c_ge3m": c.ge3m.mean(),
            "fp_recall": nc.fp_recall.mean(), "over": nc.over.mean(),
            "nc_ge3m": nc.ge3m.mean(), "nc_workup": nc.nc_workup.mean()}


def paired_ci(d, n_boot=10000, seed=0):
    """Mean of paired per-patient differences d with a 95% percentile bootstrap CI, in pp.

    The single bootstrap routine of the study: every comparison (one endpoint, one stratum) gets its own
    generator seeded with `seed`, and d lists the patients in ID order, so the same comparison gives the same
    interval in every script."""
    d = np.asarray(d, float)
    rng = np.random.default_rng(seed)
    bs = d[rng.integers(0, len(d), size=(n_boot, len(d)))].mean(1)
    return 100 * d.mean(), 100 * np.percentile(bs, 2.5), 100 * np.percentile(bs, 97.5)


def bootstrap_diff(pa: pd.DataFrame, pb: pd.DataFrame, key: str, n_boot=10000, seed=0):
    """Paired, patient-level bootstrap stratified by cancer status; returns (diff, lo, hi) in pp."""
    grp = pa.cancer.to_numpy()
    sub = grp if key in ("miss", "under", "c_ge3m") else ~grp
    a = pa[key if key != "c_ge3m" else "ge3m"].to_numpy()[sub]
    b = pb[key if key != "c_ge3m" else "ge3m"].to_numpy()[sub]
    return paired_ci(a - b, n_boot, seed)
