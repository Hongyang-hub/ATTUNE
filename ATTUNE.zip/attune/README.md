# ATTUNE

Code for ATTUNE (Agreement-Targeted Tuning Under Non-inferiority via Evolution), a framework that designs lung cancer
screening follow-up rule tables for agreement between radiologists. A rule table in the format of Lung-RADS is encoded
in 14 integers, repaired to the escalation caps of Lung-RADS v2022 and applied to every one of four independent reads of
each screening CT of LIDC-annot-NLST501. Any multi-objective evolutionary algorithm can be plugged in to minimize miss
rate, under-triage, false-positive recall and recall discordance between reads; one table is then selected under
non-inferiority constraints against Lung-RADS v2022, and the whole procedure is evaluated by nested cross-validation.
Twenty algorithms are embedded: ten from pymoo and ten implemented in `src/moeas/`.

## Installation

Python 3.10 or later.

    pip install -r requirements.txt

## Data

All data are public. The CT images are not needed to reproduce the results; the derived inputs are included.

| Data | Source | Location |
|---|---|---|
| LIDC-annot-NLST501 annotation, patient and correction tables, CT and SEG manifests | The Cancer Imaging Archive, doi:10.7937/y2dx-e334 | `data/raw/nlst501/` |
| LUNA25 table `LUNA25_Public_Training_Development_Data.csv` | Zenodo, doi:10.5281/zenodo.14223624 | `data/raw/luna25/` |
| Participant-level split (fold -1: test set; folds 0-4: development folds) | this repository | `data/splits.json` |
| Automated solid-component diameters of the segmented findings (-300 HU and -200 HU) | derived, `scripts/solid_component.py` | `data/derived/solid_component.csv` |
| Nodule signs predicted by the multi-task sign reader: out-of-fold for the development set, and for LUNGx and LUNA25 | derived | `data/derived/sign_reader/` |

To recompute the solid component, download the CT series (`python scripts/download_ct.py` and
`bash scripts/download_corrected.sh`) and the segmentation series (`python scripts/download_seg.py`), then run
`python scripts/solid_component.py`.

## Running

Run from the repository root:

    bash run_all.sh 16        # 16 parallel processes

| Step | Script | Output |
|---|---|---|
| Searches: 20 algorithms, main design and five nested outer folds, seeds 0-9 (1,200 runs of 10,000 evaluations) | `scripts/run_searches.sh`, `scripts/run_search.py` | `runs/search/<design>_<algo>_s<seed>.npz` |
| First tier by hypervolume, primary analysis (pooled first tier, nested cross-validation), each algorithm alone, trade-off with the margin, test set, external data, automated reading | `scripts/evaluate_attune.py` | `runs/attune/` |
| Sources of recall discordance | `scripts/decompose_discordance.py` | `runs/discordance_sources.*` |

A single run, for example SPEA2 on the main design with seed 0, takes a few seconds on one core:

    python scripts/run_search.py --design main --seed 0 --algo spea2

Folds are numbered 0-4 in the code and 1-5 in the paper. Every run uses a fixed seed, and the initial population of a
seed is the same for all algorithms.

## Code

| File | Content |
|---|---|
| `src/rules.py` | coding of the radiologists' findings |
| `src/search.py` | rule-table encoding, repair, Lung-RADS v2022 comparator, evaluation on multi-reader data, selection rule |
| `src/metrics.py` | endpoints and bootstrap confidence intervals |
| `src/data.py` | data loading and fold design |
| `src/moeas/` | NRV-MOEA, PDMaOEA, Truthful NSGA-II, PRV-NSGA-II, MaOEA-HAP, Two_Arch2, IBEA, MOEA/D-DE, SMPSO and ADMOPSO for pymoo 0.6.2 |
| `scripts/run_search.py` | one search run with any embedded algorithm |

A new algorithm is embedded by adding `src/moeas/<name>.py` with a function
`make(sampling, repair, crossover, mutation, pop_size, ref_dirs)` that returns a pymoo algorithm, and adding `<name>` to
`EXTRA` in `scripts/run_search.py`.

## License

MIT, see `LICENSE`.
