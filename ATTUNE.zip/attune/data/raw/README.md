Place the downloaded public tables here (not redistributed):

    data/raw/nlst501/LIDC-annot-NLST501-annotations.csv
    data/raw/nlst501/LIDC-annot-NLST501-patients.csv
    data/raw/nlst501/LIDC-annot-NLST501-correction.csv
    data/raw/nlst501/source-manifest-LIDC-annot-NLST501.tcia   (only for scripts/download_ct.py)
    data/raw/nlst501/LIDC-annot-NLST501_Seg.tcia                (only for scripts/download_seg.py)
    data/raw/luna25/LUNA25_Public_Training_Development_Data.csv
